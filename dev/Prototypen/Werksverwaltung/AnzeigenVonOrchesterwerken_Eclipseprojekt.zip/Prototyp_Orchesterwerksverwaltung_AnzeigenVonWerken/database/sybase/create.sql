--
-- Selbstverwaltetes Orchester Concerto
-- Susanne Busse, Dezember 2010
--
-- Skript zum Anlegen des Datenbankschemas
--

/* Dieser Teil dient dem Loeschen des Schemas (vgl. entsprechendes drop-Skript).
   Achtung: Bei Verwendung der Kommandozeile:
   - das drop-Skript zum Loeschen verwenden, wenn die DB bereits einmal erzeugt wurde.
   - die drops hier auskommentieren, indem das folgende Kommentar-Ende geloescht wird.
*/
-- ggf. Loeschen der Tabellen
if exists (select 1
            from  sysobjects
            where id = object_id('TeiltEin')
            and   type = 'U')
   drop table TeiltEin 
-- go

if exists (select 1
            from  sysobjects
            where id = object_id('WunschVon')
            and   type = 'U')
   drop table WunschVon 
-- go

if exists (select 1
            from  sysobjects
            where id = object_id('Dienst')
            and   type = 'U')
   drop table Dienst 
-- go

if exists (select 1
            from  sysobjects
            where id = object_id('Diensttyp')
            and   type = 'U')
   drop table Diensttyp 
-- go

if exists (select 1
            from  sysobjects
            where id = object_id('Punkte')
            and   type = 'U')
   drop table Punkte 
-- go

if exists (select 1
            from  sysobjects
            where id = object_id('Punktekonto')
            and   type = 'U')
   drop table Punktekonto 
-- go

if exists (select 1
            from  sysobjects
            where id = object_id('SpielbarVon')
            and   type = 'U')
   drop table SpielbarVon 
-- go

if exists (select 1
            from  sysobjects
            where id = object_id('Substitut')
            and   type = 'U')
   drop table Substitut 
-- go

if exists (select 1
            from  sysobjects
            where id = object_id('AngestellterMusiker')
            and   type = 'U')
   drop table AngestellterMusiker 
-- go

if exists (select 1
            from  sysobjects
            where id = object_id('Bank')
            and   type = 'U')
   drop table Bank 
-- go

if exists (select 1
            from  sysobjects
            where id = object_id('Musiker')
            and   type = 'U')
   drop table Musiker 
-- go

if exists (select 1
            from  sysobjects
            where id = object_id('FestgelegtVon')
            and   type = 'U')
   drop table FestgelegtVon 
-- go

if exists (select 1
            from  sysobjects
            where id = object_id('Orchestermitglied')
            and   type = 'U')
   drop table Orchestermitglied 
-- go

if exists (select 1
            from  sysobjects
            where id = object_id('Benutzt')
            and   type = 'U')
   drop table Benutzt 
-- go

if exists (select 1
            from  sysobjects
            where id = object_id('BestehtAus')
            and   type = 'U')
   drop table BestehtAus 
-- go

if exists (select 1
            from  sysobjects
            where id = object_id('Instrumententyp')
            and   type = 'U')
   drop table Instrumententyp
-- go

if exists (select 1
            from  sysobjects
            where id = object_id('Stimmgruppe')
            and   type = 'U')
   drop table Stimmgruppe
-- go

if exists (select 1
            from  sysobjects
            where id = object_id('Besetzung')
            and   type = 'U')
   drop table Besetzung
-- go

if exists (select 1
            from  sysobjects
            where id = object_id('Orchesterwerk')
            and   type = 'U')
   drop table Orchesterwerk
go
-- */


-- Anlegen des DB-Schemas

create table Orchesterwerk (
  WerkID     Numeric(6,0)  identity
 ,Typ        Varchar(30)   not null
 ,Name       Varchar(50)   not null
 ,Komponist  Varchar(50)   not null
 ,Dauer      Numeric(3,0)  not null
 ,NotenDa    Bit           not null 
 ,PRIMARY KEY (WerkID)
)
-- go


create table Besetzung (
  BesID     Numeric(8,0)  identity  PRIMARY KEY
 ,Typ       Varchar(30)   not null
 ,WerkID    Numeric(6,0)  null      REFERENCES Orchesterwerk 
)
-- go


create table Stimmgruppe (
  Kuerzel Varchar(10)   not null 	        
 ,Name    Varchar(15)   not null
 ,PRIMARY KEY (Kuerzel)
)
-- go


create table Instrumententyp (
  InstrID Numeric(5,0) identity  PRIMARY KEY 
 ,Name    Varchar(30)  not null 
 ,Kuerzel Char(5)      null
 ,Art     Char(6)      not null  check(Art in ('Haupt', 'Schlag'))
 ,StimmgrKuerzel Varchar(10) not null REFERENCES Stimmgruppe
)
-- go


create table Benutzt (
  BesID        Numeric(8,0)  not null
 ,InstrID      Numeric(5,0)  not null
 ,Anzahl       Numeric(3,0)  null
 ,GespieltVon  Varchar(20)  null
 ,PRIMARY KEY (BesID, InstrID)
 ,FOREIGN KEY (BesID)   REFERENCES Besetzung
 ,FOREIGN KEY (InstrID) REFERENCES Instrumententyp
)
-- go


create table Orchestermitglied (
  OMitglID  Numeric(5,0)  identity
 ,Name      Varchar(30)   not null
 ,Vorname   Varchar(30)   not null
 ,Kuerzel   Char(3)       not null
 ,Strasse   Varchar(40)   null
 ,Hausnr    Varchar(10)   null
 ,PLZ       Numeric(5,0)  null
 ,Ort       Varchar(30)   null
 ,PRIMARY KEY (OMitglID)
)
-- go

-- Dirigent wird nicht als separate Tabelle angelegt.
-- Alle Orchestermitglieder, die nicht bei Musiker enthalten sind,
--  sind Dirigenten.
create table FestgelegtVon (
  BesID     Numeric(8,0)  not null
 ,OMitglID  Numeric(5,0)  not null
 ,PRIMARY KEY(BesID)
 ,FOREIGN KEY(BesID)    REFERENCES Besetzung
 ,FOREIGN KEY(OMitglID) REFERENCES Orchestermitglied
)
-- go


create table Musiker (
  OMitglID  Numeric(5,0)  not null
 ,PRIMARY KEY(OMitglID)
 ,FOREIGN KEY(OMitglID) REFERENCES Orchestermitglied
)
-- go

create table Bank (
  BLZ             Numeric(8,0)  not null
 ,Kreditinstitut  Varchar(40)   not null
 ,PRIMARY KEY(BLZ)
)
-- go


create table AngestellterMusiker (
  OMitglID        Numeric(5,0)  not null
 ,GebDatum        Date          null
 ,GebOrt          Varchar(30)   null
 ,BLZ             Numeric(8,0)  not null
 ,Kontonr         Numeric(10)   not null
 ,Anstellung      Date          not null
 ,IstSolist       Bit           not null
 ,IstStimmfuehrer Bit           not null
 ,StimmgrKuerzel  Varchar(10)   not null
 ,PRIMARY KEY(OMitglID)
 ,FOREIGN KEY(OMitglID) REFERENCES Musiker
 ,FOREIGN KEY (StimmgrKuerzel) REFERENCES Stimmgruppe
 ,FOREIGN KEY (BLZ) REFERENCES Bank
)
-- go

create table Substitut (
  OMitglID  Numeric(5,0)  not null
 ,MusikerID Numeric(5,0)  not null
 ,PRIMARY KEY(OMitglID)
 ,FOREIGN KEY(OMitglID)  REFERENCES Musiker
 ,FOREIGN KEY(MusikerID) REFERENCES AngestellterMusiker
)
-- go


create table SpielbarVon (
  InstrID   Numeric(5,0)  not null
 ,OMitglID  Numeric(5,0)  not null
 ,PRIMARY KEY (InstrID, OMitglID)
 ,FOREIGN KEY (InstrID)  REFERENCES Instrumententyp
 ,FOREIGN KEY (OMitglID) REFERENCES AngestellterMusiker
)
-- go

create table Punktekonto (
  OMitglID    Numeric(5,0)  not null
 ,Jahr        Numeric(4,0)  not null
 ,Monat       Numeric(2,0)  not null check(Monat < 13)
 ,Punktestand Numeric(5,0)  default 0  not null
 ,PRIMARY KEY (OMitglID, Jahr, Monat)
 ,FOREIGN KEY (OMitglID) REFERENCES AngestellterMusiker
)
-- go

create table Punkte (
  PunkteID         Numeric(9,0)  identity
 ,PktStimmfuehrer  Numeric(2,0)  null
 ,PktTutti         Numeric(2,0)  not null
 ,PktSolist        Numeric(2,0)  null
 ,PktErsatz        Numeric(2,0)  null
 ,PRIMARY KEY (PunkteID)
)
-- go

create table Diensttyp (
  Name      Varchar(26)   not null
 ,PunkteID  Numeric(9,0)  not null
 ,PRIMARY KEY (Name)
 ,FOREIGN KEY (PunkteID) REFERENCES Punkte
)
-- go

create table Dienst (
  DienstID  Numeric(12,0) identity
 ,Beginn    Datetime      not null
 ,Tageszeit Char(1)       not null  check(Tageszeit in ('v', 'n', 'a'))
 ,Dauer     Numeric(5,0)  not null
 ,Name      Varchar(40)   null
 ,Bemerkung Varchar(256)  null
 ,Diensttyp Varchar(26)   not null
 ,BesID     Numeric(8,0)  null
 ,PunkteID  Numeric(9,0)  null
 ,PRIMARY KEY (DienstID)
 ,FOREIGN KEY (Diensttyp) REFERENCES Diensttyp
 ,FOREIGN KEY (BesID)    REFERENCES Besetzung
 ,FOREIGN KEY (PunkteID) REFERENCES Punkte
)
-- go

create table WunschVon (
  DienstID    Numeric(12,0)  not null
 ,OMitglID    Numeric(5,0)   not null
 ,IstPositiv  Bit            not null
 ,PRIMARY KEY (DienstID, OMitglID)
 ,FOREIGN KEY (DienstID) REFERENCES Dienst
 ,FOREIGN KEY (OMitglID) REFERENCES AngestellterMusiker
)
-- go

create table TeiltEin (
  DienstID    Numeric(12,0)  not null
 ,OMitglID    Numeric(5,0)   not null
 ,InstrID     Numeric(5,0)   not null
 ,AlsErsatz   Bit            not null
 ,AlsStimmfuehrer  Bit       not null
 ,Position    Numeric(1,0)   null
 ,Gespielt    Char(1)        null  check(Gespielt in ('y','n'))
 ,PRIMARY KEY (DienstID, OMitglID)
 ,FOREIGN KEY (DienstID) REFERENCES Dienst
 ,FOREIGN KEY (OMitglID) REFERENCES Musiker
 ,FOREIGN KEY (InstrID)  REFERENCES Instrumententyp
)
-- go
