--
-- Selbstverwaltetes Orchester Concerto
-- Susanne Busse, Dezember 2010
--
-- Skript zum L�schen des Datenbankschemas
--


-- ggf. Loeschen der Tabellen
if exists (select 1
            from  sysobjects
            where id = object_id('TeiltEin')
            and   type = 'U')
   drop table TeiltEin 
-- go

if exists (select 1
            from  sysobjects
            where id = object_id('WunschVon')
            and   type = 'U')
   drop table WunschVon 
-- go

if exists (select 1
            from  sysobjects
            where id = object_id('Dienst')
            and   type = 'U')
   drop table Dienst 
-- go

if exists (select 1
            from  sysobjects
            where id = object_id('Diensttyp')
            and   type = 'U')
   drop table Diensttyp 
-- go

if exists (select 1
            from  sysobjects
            where id = object_id('Punkte')
            and   type = 'U')
   drop table Punkte 
-- go

if exists (select 1
            from  sysobjects
            where id = object_id('Punktekonto')
            and   type = 'U')
   drop table Punktekonto 
-- go

if exists (select 1
            from  sysobjects
            where id = object_id('SpielbarVon')
            and   type = 'U')
   drop table SpielbarVon 
-- go

if exists (select 1
            from  sysobjects
            where id = object_id('Substitut')
            and   type = 'U')
   drop table Substitut 
-- go

if exists (select 1
            from  sysobjects
            where id = object_id('AngestellterMusiker')
            and   type = 'U')
   drop table AngestellterMusiker 
-- go

if exists (select 1
            from  sysobjects
            where id = object_id('Bank')
            and   type = 'U')
   drop table Bank 
-- go

if exists (select 1
            from  sysobjects
            where id = object_id('Musiker')
            and   type = 'U')
   drop table Musiker 
-- go

if exists (select 1
            from  sysobjects
            where id = object_id('FestgelegtVon')
            and   type = 'U')
   drop table FestgelegtVon 
-- go

if exists (select 1
            from  sysobjects
            where id = object_id('Orchestermitglied')
            and   type = 'U')
   drop table Orchestermitglied 
-- go

if exists (select 1
            from  sysobjects
            where id = object_id('Benutzt')
            and   type = 'U')
   drop table Benutzt 
-- go

if exists (select 1
            from  sysobjects
            where id = object_id('BestehtAus')
            and   type = 'U')
   drop table BestehtAus 
-- go

if exists (select 1
            from  sysobjects
            where id = object_id('Instrumententyp')
            and   type = 'U')
   drop table Instrumententyp
-- go

if exists (select 1
            from  sysobjects
            where id = object_id('Stimmgruppe')
            and   type = 'U')
   drop table Stimmgruppe
-- go

if exists (select 1
            from  sysobjects
            where id = object_id('Besetzung')
            and   type = 'U')
   drop table Besetzung
-- go

if exists (select 1
            from  sysobjects
            where id = object_id('Orchesterwerk')
            and   type = 'U')
   drop table Orchesterwerk
-- go

