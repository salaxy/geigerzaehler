--
-- Selbstverwaltetes Orchester Concerto
-- Susanne Busse, Dezember 2010
-- Beispieldaten

-- Achtung: Dieses Skript kann so nicht ueber die Kommandozeile ausgefuehrt werden!
-- Es muesste dann in Einzelteile zerlegt werden.

-- Daten zu Orchesterwerk(Typ, Name, Komponist, Dauer, NotenDa)
INSERT INTO Orchesterwerk(Typ, Name, Komponist, Dauer, NotenDa) 
  VALUES ('Oper', 'Cos� fan tutte', 'Wolfgang Amadeus Mozart', 180, 1)

INSERT INTO Orchesterwerk(Typ, Name, Komponist, Dauer, NotenDa) 
  VALUES ('Oper', 'Manon', 'Giacomo Puccini', 120, 0)

INSERT INTO Orchesterwerk(Typ, Name, Komponist, Dauer, NotenDa) 
  VALUES ('Oper', 'Don Giovanni', 'Wolfgang Amadeus Mozart', 165, 1)

INSERT INTO Orchesterwerk(Typ, Name, Komponist, Dauer, NotenDa) 
  VALUES ('Operette', 'Der Vogelh�ndler', 'Carl Zeller', 150, 1)

COMMIT
go


-- Daten zu Stimmgruppe(Kuerzel, Name)
INSERT INTO Stimmgruppe VALUES ('Streicher', 'Streicher')     
INSERT INTO Stimmgruppe VALUES ('Holz', 'Holzbl�ser')         
INSERT INTO Stimmgruppe VALUES ('Blech', 'Blechbl�ser')       
INSERT INTO Stimmgruppe VALUES ('Schlagwerk', 'Schlagwerk')   
COMMIT
go


-- Daten zu Instrumententyp(Name, Kuerzel, Art, Stimmgruppe) 
INSERT INTO Instrumententyp(Name, Kuerzel, Art, StimmgrKuerzel)  
 VALUES ('1. Violine', 'Vl1', 'Haupt', 'Streicher')
INSERT INTO Instrumententyp(Name, Kuerzel, Art, StimmgrKuerzel)  
 VALUES ('2. Violine', 'Vl2', 'Haupt', 'Streicher')
INSERT INTO Instrumententyp(Name, Kuerzel, Art, StimmgrKuerzel) 
 VALUES ('Viola', 'Vla', 'Haupt', 'Streicher')
INSERT INTO Instrumententyp(Name, Kuerzel, Art, StimmgrKuerzel) 
 VALUES ('Violoncelli', 'Vc', 'Haupt', 'Streicher')
INSERT INTO Instrumententyp(Name, Kuerzel, Art, StimmgrKuerzel) 
 VALUES ('Kontrabass', 'Kb', 'Haupt', 'Streicher')

INSERT INTO Instrumententyp(Name, Kuerzel, Art, StimmgrKuerzel) 
 VALUES ('Fl�te', 'Fl', 'Haupt', 'Holz')
INSERT INTO Instrumententyp(Name, Kuerzel, Art, StimmgrKuerzel) 
 VALUES ('Piccolofl�te', 'Picc', 'Haupt', 'Holz')
INSERT INTO Instrumententyp(Name, Kuerzel, Art, StimmgrKuerzel) 
 VALUES ('Oboe', 'Ob', 'Haupt', 'Holz')
INSERT INTO Instrumententyp(Name, Kuerzel, Art, StimmgrKuerzel) 
 VALUES ('Englischhorn', 'Eh', 'Haupt', 'Holz')
INSERT INTO Instrumententyp(Name, Kuerzel, Art, StimmgrKuerzel) 
 VALUES ('Klarinette', 'Kl', 'Haupt', 'Holz')
INSERT INTO Instrumententyp(Name, Kuerzel, Art, StimmgrKuerzel) 
 VALUES ('Bassklarinette', 'BKl', 'Haupt', 'Holz')
INSERT INTO Instrumententyp(Name, Kuerzel, Art, StimmgrKuerzel) 
 VALUES ('Bassetthorn', 'Bh', 'Haupt', 'Holz')
INSERT INTO Instrumententyp(Name, Kuerzel, Art, StimmgrKuerzel) 
 VALUES ('Fagott', 'Fg', 'Haupt', 'Holz')
INSERT INTO Instrumententyp(Name, Kuerzel, Art, StimmgrKuerzel) 
 VALUES ('Kontrafagott', 'Kfg', 'Haupt', 'Holz')

INSERT INTO Instrumententyp(Name, Kuerzel, Art, StimmgrKuerzel) 
 VALUES ('Horn', 'Hr', 'Haupt', 'Blech')
INSERT INTO Instrumententyp(Name, Kuerzel, Art, StimmgrKuerzel) 
 VALUES ('Wagnertuba', 'Wtb', 'Haupt', 'Blech')
INSERT INTO Instrumententyp(Name, Kuerzel, Art, StimmgrKuerzel) 
 VALUES ('Trompete', 'Tr', 'Haupt', 'Blech')
INSERT INTO Instrumententyp(Name, Kuerzel, Art, StimmgrKuerzel) 
 VALUES ('Posaune', 'Pos', 'Haupt', 'Blech')
INSERT INTO Instrumententyp(Name, Kuerzel, Art, StimmgrKuerzel) 
 VALUES ('Cimbasso', 'KbPos', 'Haupt', 'Blech')
INSERT INTO Instrumententyp(Name, Kuerzel, Art, StimmgrKuerzel) 
 VALUES ('Tuba', 'Tb', 'Haupt', 'Blech')

INSERT INTO Instrumententyp(Name, Kuerzel, Art, StimmgrKuerzel) 
 VALUES ('Pauke', 'Pk', 'Haupt', 'Schlagwerk')
INSERT INTO Instrumententyp(Name, Kuerzel, Art, StimmgrKuerzel) 
 VALUES ('Schlagwerk', 'Schlw', 'Haupt', 'Schlagwerk')
INSERT INTO Instrumententyp(Name, Kuerzel, Art, StimmgrKuerzel) 
 VALUES ('Harfe', 'Hf', 'Haupt', 'Schlagwerk')
INSERT INTO Instrumententyp(Name, Kuerzel, Art, StimmgrKuerzel) 
 VALUES ('Klavier', 'P', 'Haupt', 'Schlagwerk')
INSERT INTO Instrumententyp(Name, Kuerzel, Art, StimmgrKuerzel) 
 VALUES ('Akkordeon', 'Acc', 'Haupt', 'Schlagwerk')
INSERT INTO Instrumententyp(Name, Kuerzel, Art, StimmgrKuerzel) 
 VALUES ('Gitarre', 'Git', 'Haupt', 'Schlagwerk')
INSERT INTO Instrumententyp(Name, Kuerzel, Art, StimmgrKuerzel) 
 VALUES ('Mandoline', 'Mand', 'Haupt', 'Schlagwerk')
-- Daten ohne Kuerzel
INSERT INTO Instrumententyp(Name, Art, StimmgrKuerzel) 
 VALUES ('Kleine Trommel', 'Schlag', 'Schlagwerk')
INSERT INTO Instrumententyp(Name, Art, StimmgrKuerzel)
 VALUES ('Gro�e Trommel', 'Schlag', 'Schlagwerk')
INSERT INTO Instrumententyp(Name, Art, StimmgrKuerzel)
 VALUES ('Tom Tom', 'Schlag', 'Schlagwerk')
INSERT INTO Instrumententyp(Name, Art, StimmgrKuerzel)
 VALUES ('Becken', 'Schlag', 'Schlagwerk')
COMMIT
go


-- Daten zu Besetzung(Typ, WerkID) und den ben�tigten Instrumententypen
--  Benutzt(BesID, InstrID, Anzahl, GespieltVon)

-- Hofkapellenbesetzung nur mit Streichern
INSERT INTO Besetzung(Typ) VALUES ('spezifisch')
INSERT INTO Benutzt VALUES (1,1,4,null)
INSERT INTO Benutzt VALUES (1,2,3,null)
INSERT INTO Benutzt VALUES (1,4,2,null)
INSERT INTO Benutzt VALUES (1,5,1,null)

-- Original-Besetzung von Cosi fan tutte
INSERT INTO Besetzung(Typ, WerkID) VALUES ('Wunschbesetzung', 1)
INSERT INTO Benutzt VALUES (2,1,null,null)
INSERT INTO Benutzt VALUES (2,2,null,null)
INSERT INTO Benutzt VALUES (2,6,2,null)
INSERT INTO Benutzt VALUES (2,8,2,null)
INSERT INTO Benutzt VALUES (2,10,2,null)
INSERT INTO Benutzt VALUES (2,13,2,null)
INSERT INTO Benutzt VALUES (2,15,2,null)
INSERT INTO Benutzt VALUES (2,17,2,null)
INSERT INTO Benutzt VALUES (2,21,null,null)

-- Verfeinerte Besetzung von Cosi fan tutte
INSERT INTO Besetzung(Typ, WerkID) VALUES ('spezifisch', 1)
INSERT INTO Benutzt VALUES (3,1,8,null)
INSERT INTO Benutzt VALUES (3,2,8,null)
INSERT INTO Benutzt VALUES (3,3,6,null)
INSERT INTO Benutzt VALUES (3,4,4,null)
INSERT INTO Benutzt VALUES (3,5,2,null)
INSERT INTO Benutzt VALUES (3,6,2,null)
INSERT INTO Benutzt VALUES (3,8,2,null)
INSERT INTO Benutzt VALUES (3,10,2,null)
INSERT INTO Benutzt VALUES (3,13,2,null)
INSERT INTO Benutzt VALUES (3,15,2,null)
INSERT INTO Benutzt VALUES (3,17,2,null)
INSERT INTO Benutzt VALUES (3,21,1,null)


-- Spezifische Besetzung von Manon
INSERT INTO Besetzung(Typ, WerkID) VALUES ('spezifisch', 2)
INSERT INTO Benutzt VALUES (4,1,8,null)
INSERT INTO Benutzt VALUES (4,2,8,null)
INSERT INTO Benutzt VALUES (4,3,6,null)
INSERT INTO Benutzt VALUES (4,4,6,null)
INSERT INTO Benutzt VALUES (4,5,4,null)
INSERT INTO Benutzt VALUES (4,6,3,null)
INSERT INTO Benutzt VALUES (4,8,2,null)
INSERT INTO Benutzt VALUES (4,10,2,null)
INSERT INTO Benutzt VALUES (4,13,2,null)
INSERT INTO Benutzt VALUES (4,7,null,'3. Fl')
INSERT INTO Benutzt VALUES (4,9,1,null)
INSERT INTO Benutzt VALUES (4,11,1,null)
INSERT INTO Benutzt VALUES (4,15,4,null)
INSERT INTO Benutzt VALUES (4,17,3,null)
INSERT INTO Benutzt VALUES (4,18,3,null)
INSERT INTO Benutzt VALUES (4,20,1,null)
INSERT INTO Benutzt VALUES (4,21,1,null)
INSERT INTO Benutzt VALUES (4,22,1,null)
INSERT INTO Benutzt VALUES (4,23,1,null)
COMMIT
go

-- Original-Besetzung von Don Giovanni
INSERT INTO Besetzung(Typ, WerkID) VALUES ('Wunschbesetzung', 3)
INSERT INTO Benutzt VALUES (5,1,null,null)
INSERT INTO Benutzt VALUES (5,2,null,null)
INSERT INTO Benutzt VALUES (5,3,null,null)
INSERT INTO Benutzt VALUES (5,5,null,null)
INSERT INTO Benutzt VALUES (5,6,2,null)
INSERT INTO Benutzt VALUES (5,8,2,null)
INSERT INTO Benutzt VALUES (5,10,2,null)
INSERT INTO Benutzt VALUES (5,13,2,null)
INSERT INTO Benutzt VALUES (5,15,2,null)
INSERT INTO Benutzt VALUES (5,17,2,null)
INSERT INTO Benutzt VALUES (5,18,3,null)
INSERT INTO Benutzt VALUES (5,21,null,null)
INSERT INTO Benutzt VALUES (5,27,1,null)


-- Punkte der Dienste und -typen 
INSERT INTO Punkte(PktStimmfuehrer, PktTutti, PktSolist, PktErsatz)
  VALUES (12, 10, 12, 6)
INSERT INTO Punkte(PktStimmfuehrer, PktTutti, PktSolist, PktErsatz)
  VALUES (6, 5, 6, 3)
INSERT INTO Punkte(PktStimmfuehrer, PktTutti, PktSolist, PktErsatz)
  VALUES (10, 8, 10, 5)
INSERT INTO Punkte(PktStimmfuehrer, PktTutti, PktSolist, PktErsatz)
  VALUES (5, 4, 5, 3)
INSERT INTO Punkte(PktStimmfuehrer, PktTutti, PktSolist, PktErsatz)
  VALUES (16, 13, 16, 9)
INSERT INTO Punkte(PktStimmfuehrer, PktTutti, PktSolist, PktErsatz)
  VALUES (null, 5, null, null)
INSERT INTO Punkte(PktStimmfuehrer, PktTutti, PktSolist, PktErsatz)
  VALUES (null, 2, null, null)
INSERT INTO Punkte(PktStimmfuehrer, PktTutti, PktSolist, PktErsatz)
  VALUES (7, 6, 7, null)
COMMIT
go


-- Diensttypen(Name, PunkteID)
INSERT INTO Diensttyp VALUES ('Oper-Auff�hrung', 1)
INSERT INTO Diensttyp VALUES ('Oper-Probe', 2)
INSERT INTO Diensttyp VALUES ('Konzert-Auff�hrung', 3)
INSERT INTO Diensttyp VALUES ('Konzert-Probe', 4)
INSERT INTO Diensttyp VALUES ('Tourneedienst', 5)
INSERT INTO Diensttyp VALUES ('Hofkapelle', 6)
INSERT INTO Diensttyp VALUES ('Nicht-musikalischer Dienst', 7)
COMMIT
go


-- Dienste(Beginn, Tageszeit, Dauer, Name, Bemerkung, Diensttyp, BesID, PunkteID)
INSERT INTO Dienst(Beginn, Tageszeit, Dauer, Name, Bemerkung, Diensttyp, BesID, PunkteID)
  VALUES ('20101227 9:00', 'v', 180, null, null, 'Oper-Probe', 3, 8)
INSERT INTO Dienst(Beginn, Tageszeit, Dauer, Name, Bemerkung, Diensttyp, BesID, PunkteID)
  VALUES ('20101228 9:00', 'v', 120, null, null, 'Oper-Probe', 3, null)
INSERT INTO Dienst(Beginn, Tageszeit, Dauer, Name, Bemerkung, Diensttyp, BesID, PunkteID)
  VALUES ('20101228 15:00', 'n', 60, 'Besprechung', 'Besprechung der Diensteinteilungs-Verantwortlichen', 'Nicht-musikalischer Dienst', null, null)
INSERT INTO Dienst(Beginn, Tageszeit, Dauer, Name, Bemerkung, Diensttyp, BesID, PunkteID)
  VALUES ('20101229 19:00', 'a', 240, null, null, 'Oper-Auff�hrung', 3, null)
INSERT INTO Dienst(Beginn, Tageszeit, Dauer, Name, Bemerkung, Diensttyp, BesID, PunkteID)
  VALUES ('20101230 19:00', 'a', 240, null, null, 'Oper-Auff�hrung', 3, null)
INSERT INTO Dienst(Beginn, Tageszeit, Dauer, Name, Bemerkung, Diensttyp, BesID, PunkteID)
  VALUES ('20110104 19:00', 'a', 240, null, null, 'Oper-Auff�hrung', 3, null)

INSERT INTO Dienst(Beginn, Tageszeit, Dauer, Name, Bemerkung, Diensttyp, BesID, PunkteID)
  VALUES ('20101229 9:00', 'v', 90, null, null, 'Oper-Probe', 4, null)
INSERT INTO Dienst(Beginn, Tageszeit, Dauer, Name, Bemerkung, Diensttyp, BesID, PunkteID)
  VALUES ('20110103 9:00', 'v', 180, null, null, 'Oper-Probe', 4, null)
INSERT INTO Dienst(Beginn, Tageszeit, Dauer, Name, Bemerkung, Diensttyp, BesID, PunkteID)
  VALUES ('20110104 9:00', 'v', 90, null, 'Vorspiel Trompete', 'Oper-Probe', null, null)
INSERT INTO Dienst(Beginn, Tageszeit, Dauer, Name, Bemerkung, Diensttyp, BesID, PunkteID)
  VALUES ('20110104 16:00', 'n', 60, null, 'Sitzung Blechbl�ser', 'Nicht-musikalischer Dienst', null, null)
INSERT INTO Dienst(Beginn, Tageszeit, Dauer, Name, Bemerkung, Diensttyp, BesID, PunkteID)
  VALUES ('20110105 9:00', 'v', 180, null, null, 'Oper-Probe', 4, null)
INSERT INTO Dienst(Beginn, Tageszeit, Dauer, Name, Bemerkung, Diensttyp, BesID, PunkteID)
  VALUES ('20110107 20:00', 'a', 180, null, null, 'Oper-Auff�hrung', 4, null)
INSERT INTO Dienst(Beginn, Tageszeit, Dauer, Name, Bemerkung, Diensttyp, BesID, PunkteID)
  VALUES ('20110108 20:00', 'a', 180, null, null, 'Oper-Auff�hrung', 4, null)
INSERT INTO Dienst(Beginn, Tageszeit, Dauer, Name, Bemerkung, Diensttyp, BesID, PunkteID)
  VALUES ('20110101 10:00', 'v', 90, null, null, 'Hofkapelle', 1, null)




-- Bankdaten zu Bank(BLZ, Kreditinstitut)
INSERT INTO Bank VALUES (13061078, 'Volks- und Raiffeisenbank')
INSERT INTO Bank VALUES (15061618, 'Raiffeisenbank Mecklenburger Seenplatte')
INSERT INTO Bank VALUES (16060122, 'Volks- und Raiffeisenbank Prignitz')
INSERT INTO Bank VALUES (16062073, 'Brandenburger Bank')
INSERT INTO Bank VALUES (30060601, 'apoBank')
INSERT INTO Bank VALUES (37060590, 'Sparda-Bank West')
INSERT INTO Bank VALUES (10050000, 'Landesbank Berlin - Berliner Sparkasse')
INSERT INTO Bank VALUES (10050600, 'WestLB Berlin')
INSERT INTO Bank VALUES (16050000, 'mbSparkasse in Potsdam')
INSERT INTO Bank VALUES (12070000, 'Deutsche Bank')
INSERT INTO Bank VALUES (16040000, 'Commerzbank')
INSERT INTO Bank VALUES (15080000, 'Dresdner Bank')
INSERT INTO Bank VALUES (12030000, 'Deutsche Kreditbank')
INSERT INTO Bank VALUES (10000000, 'Bundesbank')
COMMIT
go



-- Daten zu Orchestermitglied (Name, Vorname, Kuerzel, Strasse, Hausnr, PLZ, Ort)
--                   Musiker  (OMitglID)
--        AngestellterMusiker (OMitglID, GebDatum, GebOrt, BLZ, Kontonr, Anstellung
--                             IstSolist, IstStimmfuehrer, StimmgrKuerzel)
-- 10 Musiker insb. fuer Vl1
INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel, Strasse, Hausnr, PLZ, Ort)
  VALUES ('Fidelmann', 'Fritz', 'FrF', 'Mozartgasse', '3a', 14770, 'Brandenburg a.d. Havel')
INSERT INTO Musiker VALUES (1)
INSERT INTO AngestellterMusiker (OMitglID, GebDatum, GebOrt, BLZ, Kontonr, Anstellung,
        IstSolist, IstStimmfuehrer, StimmgrKuerzel) VALUES
        (1, '18-MAR-1960', 'Berlin', 16040000, 4689524377, '01-JAN-2003', 1, 1, 'Streicher')

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel, Strasse, Hausnr, PLZ, Ort)
  VALUES ('Violicci', 'Viola', 'ViV', 'Brahmsstra�e', '12', 14770, 'Brandenburg a.d. Havel')
INSERT INTO Musiker VALUES (2)
INSERT INTO AngestellterMusiker (OMitglID, GebDatum, GebOrt, BLZ, Kontonr, Anstellung,
        IstSolist, IstStimmfuehrer, StimmgrKuerzel) VALUES
        (2, '15-JUN-1975', 'Brandenburg a.d. Havel', 13061078, 2346277811, '01-JAN-2005', 1, 1, 'Streicher')

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Bauer', 'Berta', 'BeB')
INSERT INTO Musiker VALUES (3)
INSERT INTO AngestellterMusiker (OMitglID, BLZ, Kontonr, Anstellung,
        IstSolist, IstStimmfuehrer, StimmgrKuerzel) 
    VALUES (3, 12070000, 3452990912, '15-JAN-2005', 1, 0, 'Streicher')

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Akkord', 'Achim', 'AcA')
INSERT INTO Musiker VALUES (4)
INSERT INTO AngestellterMusiker (OMitglID, BLZ, Kontonr, Anstellung,
        IstSolist, IstStimmfuehrer, StimmgrKuerzel) 
    VALUES (4, 12070000, 3928399111, '01-JUL-2000', 0, 1, 'Streicher')

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Bellini', 'Bruno', 'BrB')
INSERT INTO Musiker VALUES (5)
INSERT INTO AngestellterMusiker (OMitglID, BLZ, Kontonr, Anstellung,
        IstSolist, IstStimmfuehrer, StimmgrKuerzel) 
    VALUES (5, 16040000, 3452990912, '15-AUG-2005', 1, 1, 'Streicher')

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Sauer', 'Sabine', 'SaS')
INSERT INTO Musiker VALUES (6)
INSERT INTO AngestellterMusiker (OMitglID, BLZ, Kontonr, Anstellung,
        IstSolist, IstStimmfuehrer, StimmgrKuerzel) 
    VALUES (6, 12030000, 3444989912, '15-DEC-2002', 1, 0, 'Streicher')

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Frack', 'Fabian', 'FaF')
INSERT INTO Musiker VALUES (7)
INSERT INTO AngestellterMusiker (OMitglID, BLZ, Kontonr, Anstellung,
        IstSolist, IstStimmfuehrer, StimmgrKuerzel) 
    VALUES (7, 12030000, 1212889666, '01-JUL-2002', 0, 0, 'Streicher')

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Faul', 'Fix', 'FiF')
INSERT INTO Musiker VALUES (8)
INSERT INTO AngestellterMusiker (OMitglID, BLZ, Kontonr, Anstellung,
        IstSolist, IstStimmfuehrer, StimmgrKuerzel) 
    VALUES (8, 12030000, 3337677672, '01-AUG-2002', 0, 0, 'Streicher')

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Seiler', 'Susi', 'SuS')
INSERT INTO Musiker VALUES (9)
INSERT INTO AngestellterMusiker (OMitglID, BLZ, Kontonr, Anstellung,
        IstSolist, IstStimmfuehrer, StimmgrKuerzel) 
    VALUES (9, 13061078, 2238900111, '15-JAN-2003', 0, 0, 'Streicher')

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Stimme', 'Stefan', 'StS')
INSERT INTO Musiker VALUES (10)
INSERT INTO AngestellterMusiker (OMitglID, BLZ, Kontonr, Anstellung,
        IstSolist, IstStimmfuehrer, StimmgrKuerzel) 
    VALUES (10, 13061078, 3444989912, '15-DEC-2002', 0, 0, 'Streicher')
COMMIT
go


-- 10 Musiker insb. fuer Vl2
INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel, Strasse, Hausnr, PLZ, Ort)
  VALUES ('Opel', 'Ophelia', 'OpO', 'Mozartgasse', '5', 14770, 'Brandenburg a.d. Havel')
INSERT INTO Musiker VALUES (11)
INSERT INTO AngestellterMusiker (OMitglID, GebDatum, GebOrt, BLZ, Kontonr, Anstellung,
        IstSolist, IstStimmfuehrer, StimmgrKuerzel) VALUES
        (11, '12-APR-1973', 'Nizza', 16040000, 3444659237, '01-JAN-2004', 0, 1, 'Streicher')

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel, Strasse, Hausnr, PLZ, Ort)
  VALUES ('Nassauer', 'Nicola', 'NiN', 'Bahnhofsstra�e', '8', 14117, 'Berlin')
INSERT INTO Musiker VALUES (12)
INSERT INTO AngestellterMusiker (OMitglID, GebDatum, GebOrt, BLZ, Kontonr, Anstellung,
        IstSolist, IstStimmfuehrer, StimmgrKuerzel) VALUES
        (12, '07-SEP-1982', 'Halle', 13061078, 7575880453, '15-SEP-2008', 0, 1, 'Streicher')

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Bauer', 'Bob', 'BoB')
INSERT INTO Musiker VALUES (13)
INSERT INTO AngestellterMusiker (OMitglID, BLZ, Kontonr, Anstellung,
        IstSolist, IstStimmfuehrer, StimmgrKuerzel) 
    VALUES (13, 12070000, 3645374577, '15-JAN-2005', 1, 0, 'Streicher')

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Zaccarias', 'Hannah', 'HaZ')
INSERT INTO Musiker VALUES (14)
INSERT INTO AngestellterMusiker (OMitglID, BLZ, Kontonr, Anstellung,
        IstSolist, IstStimmfuehrer, StimmgrKuerzel) 
    VALUES (14, 37060590, 2227508771, '15-JUL-2003', 0, 1, 'Streicher')

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Trampel', 'Timo', 'TiT')
INSERT INTO Musiker VALUES (15)
INSERT INTO AngestellterMusiker (OMitglID, BLZ, Kontonr, Anstellung,
        IstSolist, IstStimmfuehrer, StimmgrKuerzel) 
    VALUES (15, 37060590, 3456687912, '01-FEB-2003', 0, 1, 'Streicher')

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Tadel', 'Tanja', 'TaT')
INSERT INTO Musiker VALUES (16)
INSERT INTO AngestellterMusiker (OMitglID, BLZ, Kontonr, Anstellung,
        IstSolist, IstStimmfuehrer, StimmgrKuerzel) 
    VALUES (16, 12030000, 1118789912, '15-JUL-2002', 0, 0, 'Streicher')

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Dinkel', 'Dorothea', 'DoD')
INSERT INTO Musiker VALUES (17)
INSERT INTO AngestellterMusiker (OMitglID, BLZ, Kontonr, Anstellung,
        IstSolist, IstStimmfuehrer, StimmgrKuerzel) 
    VALUES (17, 12030000, 1265652296, '01-JUL-2002', 1, 0, 'Streicher')

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Voran', 'Verena', 'VeV')
INSERT INTO Musiker VALUES (18)
INSERT INTO AngestellterMusiker (OMitglID, BLZ, Kontonr, Anstellung,
        IstSolist, IstStimmfuehrer, StimmgrKuerzel) 
    VALUES (18, 37060590, 3344093672, '01-AUG-2003', 0, 0, 'Streicher')

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Wu', 'Wolfgang', 'WoW')
INSERT INTO Musiker VALUES (19)
INSERT INTO AngestellterMusiker (OMitglID, BLZ, Kontonr, Anstellung,
        IstSolist, IstStimmfuehrer, StimmgrKuerzel) 
    VALUES (19, 13061078, 2211100111, '01-AUG-2003', 0, 0, 'Streicher')

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Ricardo', 'Ronaldo', 'RoR')
INSERT INTO Musiker VALUES (20)
INSERT INTO AngestellterMusiker (OMitglID, BLZ, Kontonr, Anstellung,
        IstSolist, IstStimmfuehrer, StimmgrKuerzel) 
    VALUES (20, 13061078, 3447709812, '01-JAN-2002', 0, 0, 'Streicher')
COMMIT
go


-- 10 Musiker fuer weitere Streicher 
INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel, Strasse, Hausnr, PLZ, Ort)
  VALUES ('Zwieback', 'Norbert', 'NoZ', 'T�lpelweg', '16', 14770, 'Brandenburg a.d. Havel')
INSERT INTO Musiker VALUES (21)
INSERT INTO AngestellterMusiker (OMitglID, GebDatum, GebOrt, BLZ, Kontonr, Anstellung,
        IstSolist, IstStimmfuehrer, StimmgrKuerzel) VALUES
        (21, '12-APR-1973', 'Neapel', 16040000, 3424657237, '18-SEP-2002', 0, 1, 'Streicher')

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel, Strasse, Hausnr, PLZ, Ort)
  VALUES ('Brummi', 'Bruno', 'BrB', 'Bahnhofsstra�e', '117', 14123, 'Berlin')
INSERT INTO Musiker VALUES (22)
INSERT INTO AngestellterMusiker (OMitglID, GebDatum, GebOrt, BLZ, Kontonr, Anstellung,
        IstSolist, IstStimmfuehrer, StimmgrKuerzel) VALUES
        (22, '07-SEP-1982', 'Braunschweig', 13061078, 5749387123, '01-SEP-2008', 0, 1, 'Streicher')

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Brand', 'David', 'DaB')
INSERT INTO Musiker VALUES (23)
INSERT INTO AngestellterMusiker (OMitglID, BLZ, Kontonr, Anstellung,
        IstSolist, IstStimmfuehrer, StimmgrKuerzel) 
    VALUES (23, 12070000, 3322374577, '15-JUN-2002', 0, 0, 'Streicher')

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Wu', 'Wolfgang', 'Wol')
INSERT INTO Musiker VALUES (24)
INSERT INTO AngestellterMusiker (OMitglID, BLZ, Kontonr, Anstellung,
        IstSolist, IstStimmfuehrer, StimmgrKuerzel) 
    VALUES (24, 37060590, 2245458771, '15-JAN-2001', 1, 0, 'Streicher')

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Sauber', 'Stephan', 'StS')
INSERT INTO Musiker VALUES (25)
INSERT INTO AngestellterMusiker (OMitglID, BLZ, Kontonr, Anstellung,
        IstSolist, IstStimmfuehrer, StimmgrKuerzel) 
    VALUES (25, 37060590, 3889351612, '01-FEB-2001', 0, 1, 'Streicher')

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Yu', 'Stefan', 'StY')
INSERT INTO Musiker VALUES (26)
INSERT INTO AngestellterMusiker (OMitglID, BLZ, Kontonr, Anstellung,
        IstSolist, IstStimmfuehrer, StimmgrKuerzel) 
    VALUES (26, 12030000, 4572489912, '15-JUN-2002', 0, 0, 'Streicher')

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Panne', 'Paula', 'PaP')
INSERT INTO Musiker VALUES (27)
INSERT INTO AngestellterMusiker (OMitglID, BLZ, Kontonr, Anstellung,
        IstSolist, IstStimmfuehrer, StimmgrKuerzel) 
    VALUES (27, 12030000, 1777882296, '01-JUN-2005', 0, 0, 'Streicher')

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Zappel', 'Veronika', 'VeZ')
INSERT INTO Musiker VALUES (28)
INSERT INTO AngestellterMusiker (OMitglID, BLZ, Kontonr, Anstellung,
        IstSolist, IstStimmfuehrer, StimmgrKuerzel) 
    VALUES (28, 37060590, 3347553672, '01-JAN-2001', 0, 0, 'Streicher')

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Wu', 'Paul', 'PaW')
INSERT INTO Musiker VALUES (29)
INSERT INTO AngestellterMusiker (OMitglID, BLZ, Kontonr, Anstellung,
        IstSolist, IstStimmfuehrer, StimmgrKuerzel) 
    VALUES (29, 13061078, 2211100222, '01-JAN-2003', 0, 0, 'Streicher')

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Carrell', 'Carl', 'CaC')
INSERT INTO Musiker VALUES (30)
INSERT INTO AngestellterMusiker (OMitglID, BLZ, Kontonr, Anstellung,
        IstSolist, IstStimmfuehrer, StimmgrKuerzel) 
    VALUES (30, 13061078, 3447705534, '01-JUN-2005', 0, 0, 'Streicher')
COMMIT
go

-- 2 Musiker fuer weitere Streicher + 8 Substitute f�r Streicher 
INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel, Strasse, Hausnr, PLZ, Ort)
  VALUES ('Fidelmann', 'Fritz', 'FFi', 'Badstra�e', '32', 14346, 'Potsdam')
INSERT INTO Musiker VALUES (31)
INSERT INTO AngestellterMusiker (OMitglID, GebDatum, GebOrt, BLZ, Kontonr, Anstellung,
        IstSolist, IstStimmfuehrer, StimmgrKuerzel) VALUES
        (31, '08-MAY-1979', 'M�nchen', 16040000, 3424622645, '01-SEP-2002', 1, 1, 'Streicher')

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel, Strasse, Hausnr, PLZ, Ort)
  VALUES ('Bartels', 'Felix', 'FeB', 'Hauptstra�e', '4b', 10158, 'Berlin')
INSERT INTO Musiker VALUES (32)
INSERT INTO AngestellterMusiker (OMitglID, GebDatum, GebOrt, BLZ, Kontonr, Anstellung,
        IstSolist, IstStimmfuehrer, StimmgrKuerzel) VALUES
        (32, '11-SEP-1965', 'Hamburg', 13061078, 7794237123, '31-OCT-2008', 0, 0, 'Streicher')

-- Substitute
INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Brandt', 'Samira', 'SaB')
INSERT INTO Musiker VALUES (33)
INSERT INTO Substitut(OMitglID, MusikerID) VALUES (33, 12)

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Schulze', 'Vroni', 'VrS')
INSERT INTO Musiker VALUES (34)
INSERT INTO Substitut(OMitglID, MusikerID) VALUES (34, 28)

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Ill', 'Ingo', 'InI')
INSERT INTO Musiker VALUES (35)
INSERT INTO Substitut(OMitglID, MusikerID) VALUES (35, 21)

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Volter', 'Volker', 'VoV')
INSERT INTO Musiker VALUES (36)
INSERT INTO Substitut(OMitglID, MusikerID) VALUES (36, 10)

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('goldi', 'Gustav', 'GuG')
INSERT INTO Musiker VALUES (37)
INSERT INTO Substitut(OMitglID, MusikerID) VALUES (37, 8)

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Blass', 'Dorothea', 'DoB')
INSERT INTO Musiker VALUES (38)
INSERT INTO Substitut(OMitglID, MusikerID) VALUES (38, 24)

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Schmidt', 'Waldemar', 'WaS')
INSERT INTO Musiker VALUES (39)
INSERT INTO Substitut(OMitglID, MusikerID) VALUES (39, 31)

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Schulze', 'Otto', 'OtS')
INSERT INTO Musiker VALUES (40)
INSERT INTO Substitut(OMitglID, MusikerID) VALUES (40, 31)
COMMIT
go


-- 10 Musiker fuer Holzblaeser
INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel, Strasse, Hausnr, PLZ, Ort)
  VALUES ('Wampe', 'Walli', 'WWa', 'Steinplatz', '33c', 14223, 'Potsdam')
INSERT INTO Musiker VALUES (41)
INSERT INTO AngestellterMusiker (OMitglID, GebDatum, GebOrt, BLZ, Kontonr, Anstellung,
        IstSolist, IstStimmfuehrer, StimmgrKuerzel) VALUES
        (41, '19-DEC-1945', 'Berlin', 16040000, 4498777377, '01-JUN-2003', 1, 1, 'Holz')

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel, Strasse, Hausnr, PLZ, Ort)
  VALUES ('Propper', 'Pippi', 'PiP', 'Brahmsstra�e', '16', 14770, 'Brandenburg a.d. Havel')
INSERT INTO Musiker VALUES (42)
INSERT INTO AngestellterMusiker (OMitglID, GebDatum, GebOrt, BLZ, Kontonr, Anstellung,
        IstSolist, IstStimmfuehrer, StimmgrKuerzel) VALUES
        (42, '15-JUN-1975', 'Brandenburg a.d. Havel', 13061078, 2346277811, '01-JAN-2005', 1, 1, 'Holz')

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel, Strasse, Hausnr, PLZ, Ort) 
  VALUES ('Propper', 'Paul', 'PaP', 'Brahmsstra�e', '16', 14770, 'Brandenburg a.d. Havel')
INSERT INTO Musiker VALUES (43)
INSERT INTO AngestellterMusiker (OMitglID, BLZ, Kontonr, Anstellung,
        IstSolist, IstStimmfuehrer, StimmgrKuerzel) 
    VALUES (43, 13061078, 2346277811, '01-JAN-2005', 1, 0, 'Holz')

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Last', 'Ludwig', 'LuL')
INSERT INTO Musiker VALUES (44)
INSERT INTO AngestellterMusiker (OMitglID, BLZ, Kontonr, Anstellung,
        IstSolist, IstStimmfuehrer, StimmgrKuerzel) 
    VALUES (44, 12070000, 3928399112, '01-JUN-2000', 0, 1, 'Holz')

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Ditt', 'Sandra', 'SaD')
INSERT INTO Musiker VALUES (45)
INSERT INTO AngestellterMusiker (OMitglID, BLZ, Kontonr, Anstellung,
        IstSolist, IstStimmfuehrer, StimmgrKuerzel) 
    VALUES (45, 16040000, 3112290912, '01-AUG-2000', 1, 1, 'Holz')

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Schwan', 'Gertrud', 'GeS')
INSERT INTO Musiker VALUES (46)
INSERT INTO AngestellterMusiker (OMitglID, BLZ, Kontonr, Anstellung,
        IstSolist, IstStimmfuehrer, StimmgrKuerzel) 
    VALUES (46, 12030000, 7765879912, '01-DEC-2001', 1, 0, 'Holz')

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Frack', 'Fabian', 'FFr')
INSERT INTO Musiker VALUES (47)
INSERT INTO AngestellterMusiker (OMitglID, BLZ, Kontonr, Anstellung,
        IstSolist, IstStimmfuehrer, StimmgrKuerzel) 
    VALUES (47, 12030000, 1211122666, '01-JAN-2000', 0, 0, 'Holz')

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Fleissig', 'Max', 'MaF')
INSERT INTO Musiker VALUES (48)
INSERT INTO AngestellterMusiker (OMitglID, BLZ, Kontonr, Anstellung,
        IstSolist, IstStimmfuehrer, StimmgrKuerzel) 
    VALUES (48, 12030000, 1117677672, '01-AUG-2001', 0, 0, 'Holz')

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Spitz', 'Susanne', 'SSp')
INSERT INTO Musiker VALUES (49)
INSERT INTO AngestellterMusiker (OMitglID, BLZ, Kontonr, Anstellung,
        IstSolist, IstStimmfuehrer, StimmgrKuerzel) 
    VALUES (49, 13061078, 2238977611, '01-JAN-2001', 0, 0, 'Holz')

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Tischler', 'Tim', 'TTi')
INSERT INTO Musiker VALUES (50)
INSERT INTO AngestellterMusiker (OMitglID, BLZ, Kontonr, Anstellung,
        IstSolist, IstStimmfuehrer, StimmgrKuerzel) 
    VALUES (50, 13061078, 3445559912, '01-MAR-2002', 0, 0, 'Holz')
COMMIT
go

-- 3 weitere Musiker fuer Holzblaeser + 7 Substitute f�r Holzblaeser 
INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel, Strasse, Hausnr, PLZ, Ort)
  VALUES ('Fabel', 'Fabian', 'FFa', 'Turmstra�e', '22', 14346, 'Potsdam')
INSERT INTO Musiker VALUES (51)
INSERT INTO AngestellterMusiker (OMitglID, GebDatum, GebOrt, BLZ, Kontonr, Anstellung,
        IstSolist, IstStimmfuehrer, StimmgrKuerzel) VALUES
        (51, '07-SEP-1982', 'N�rnberg', 16040000, 3444464645, '01-SEP-2002', 1, 1, 'Holz')

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel, Strasse, Hausnr, PLZ, Ort)
  VALUES ('Gregory', 'George', 'GeG', 'Havelplatz', '1', 10158, 'Berlin')
INSERT INTO Musiker VALUES (52)
INSERT INTO AngestellterMusiker (OMitglID, GebDatum, GebOrt, BLZ, Kontonr, Anstellung,
        IstSolist, IstStimmfuehrer, StimmgrKuerzel) VALUES
        (52, '11-NOV-1945', 'St. Petersburg', 13061078, 1122237123, '01-JAN-2008', 0, 0, 'Holz')

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel, Strasse, Hausnr, PLZ, Ort)
  VALUES ('Chopin', 'Gustav', 'GuC', 'Berliner Stra�e', '31', 10158, 'Berlin')
INSERT INTO Musiker VALUES (53)
INSERT INTO AngestellterMusiker (OMitglID, GebDatum, GebOrt, BLZ, Kontonr, Anstellung,
        IstSolist, IstStimmfuehrer, StimmgrKuerzel) VALUES
        (53, '11-SEP-1965', 'L�beck', 13061078, 7711237123, '31-DEC-2008', 0, 0, 'Holz')
-- Substitute
INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Habicht', 'Holger', 'HoH')
INSERT INTO Musiker VALUES (54)
INSERT INTO Substitut(OMitglID, MusikerID) VALUES (54, 41)

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Husch', 'Henrietta', 'HeH')
INSERT INTO Musiker VALUES (55)
INSERT INTO Substitut(OMitglID, MusikerID) VALUES (55, 44)

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Ingwer', 'Ines', 'IIn')
INSERT INTO Musiker VALUES (56)
INSERT INTO Substitut(OMitglID, MusikerID) VALUES (56, 44)

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Laute', 'Felix', 'FeL')
INSERT INTO Musiker VALUES (57)
INSERT INTO Substitut(OMitglID, MusikerID) VALUES (57, 44)

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Blume', 'Doris', 'DBl')
INSERT INTO Musiker VALUES (58)
INSERT INTO Substitut(OMitglID, MusikerID) VALUES (58, 46)

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Matthies', 'Gert', 'GeM')
INSERT INTO Musiker VALUES (59)
INSERT INTO Substitut(OMitglID, MusikerID) VALUES (59, 47)

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Niemann', 'Nadja', 'NNi')
INSERT INTO Musiker VALUES (60)
INSERT INTO Substitut(OMitglID, MusikerID) VALUES (60, 51)
COMMIT
go

-- 10 Musiker fuer Blech
INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel, Strasse, Hausnr, PLZ, Ort)
  VALUES ('Wolgast', 'Hubert', 'HuW', 'Mozartgasse', '1', 14770, 'Brandenburg a.d. Havel')
INSERT INTO Musiker VALUES (61)
INSERT INTO AngestellterMusiker (OMitglID, GebDatum, GebOrt, BLZ, Kontonr, Anstellung,
        IstSolist, IstStimmfuehrer, StimmgrKuerzel) VALUES
        (61, '20-NOV-1948', 'Berlin', 16040000, 4623477377, '01-JAN-2001', 1, 1, 'Blech')

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel, Strasse, Hausnr, PLZ, Ort)
  VALUES ('Daun', 'Dietrich', 'DiD', 'Chopingasse', '2', 14770, 'Brandenburg a.d. Havel')
INSERT INTO Musiker VALUES (62)
INSERT INTO AngestellterMusiker (OMitglID, GebDatum, GebOrt, BLZ, Kontonr, Anstellung,
        IstSolist, IstStimmfuehrer, StimmgrKuerzel) VALUES
        (62, '25-JUL-1983', 'Brandenburg a.d. Havel', 13061078, 2344444811, '01-JAN-2010', 1, 1, 'Blech')

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Fr�hlich', 'Ferdinand', 'FFr')
INSERT INTO Musiker VALUES (63)
INSERT INTO AngestellterMusiker (OMitglID, BLZ, Kontonr, Anstellung,
        IstSolist, IstStimmfuehrer, StimmgrKuerzel) 
    VALUES (63, 12070000, 3422770912, '15-JAN-2002', 1, 0, 'Blech')

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Clay', 'Alexander', 'AlC')
INSERT INTO Musiker VALUES (64)
INSERT INTO AngestellterMusiker (OMitglID, BLZ, Kontonr, Anstellung,
        IstSolist, IstStimmfuehrer, StimmgrKuerzel) 
    VALUES (64, 12070000, 3921274111, '01-JUL-2010', 0, 1, 'Blech')

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Claudius', 'Charles', 'ChC')
INSERT INTO Musiker VALUES (65)
INSERT INTO AngestellterMusiker (OMitglID, BLZ, Kontonr, Anstellung,
        IstSolist, IstStimmfuehrer, StimmgrKuerzel) 
    VALUES (65, 16040000, 3452990912, '01-JAN-2000', 1, 1, 'Blech')

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Stieglitz', 'Frieda', 'FrS')
INSERT INTO Musiker VALUES (66)
INSERT INTO AngestellterMusiker (OMitglID, BLZ, Kontonr, Anstellung,
        IstSolist, IstStimmfuehrer, StimmgrKuerzel) 
    VALUES (66, 12030000, 3444989332, '15-DEC-2001', 1, 0, 'Blech')

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Fassbinder', 'Harald', 'HaF')
INSERT INTO Musiker VALUES (67)
INSERT INTO AngestellterMusiker (OMitglID, BLZ, Kontonr, Anstellung,
        IstSolist, IstStimmfuehrer, StimmgrKuerzel) 
    VALUES (67, 12030000, 1213389666, '01-JUL-2001', 0, 0, 'Blech')

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Klippe', 'Karl', 'KaK')
INSERT INTO Musiker VALUES (68)
INSERT INTO AngestellterMusiker (OMitglID, BLZ, Kontonr, Anstellung,
        IstSolist, IstStimmfuehrer, StimmgrKuerzel) 
    VALUES (68, 12030000, 3337677882, '01-AUG-2007', 0, 0, 'Blech')

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Traube', 'Thomas', 'ThT')
INSERT INTO Musiker VALUES (69)
INSERT INTO AngestellterMusiker (OMitglID, BLZ, Kontonr, Anstellung,
        IstSolist, IstStimmfuehrer, StimmgrKuerzel) 
    VALUES (69, 13061078, 2244260111, '01-JAN-2000', 0, 0, 'Blech')

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Bohne', 'Ivo', 'IvB')
INSERT INTO Musiker VALUES (70)
INSERT INTO AngestellterMusiker (OMitglID, BLZ, Kontonr, Anstellung,
        IstSolist, IstStimmfuehrer, StimmgrKuerzel) 
    VALUES (70, 13061078, 3444982212, '15-JAN-2004', 0, 0, 'Blech')
COMMIT
go

-- 10 Substitute fuer Blechblaeser
INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Lerche', 'Martha', 'MaL')
INSERT INTO Musiker VALUES (71)
INSERT INTO Substitut(OMitglID, MusikerID) VALUES (71, 62)

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Fichte', 'Henrietta', 'HeF')
INSERT INTO Musiker VALUES (72)
INSERT INTO Substitut(OMitglID, MusikerID) VALUES (72, 62)

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Mayer', 'Ingolf', 'InM')
INSERT INTO Musiker VALUES (73)
INSERT INTO Substitut(OMitglID, MusikerID) VALUES (73, 64)

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Meier', 'Rudolf', 'RuM')
INSERT INTO Musiker VALUES (74)
INSERT INTO Substitut(OMitglID, MusikerID) VALUES (74, 63)

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Birkenholz', 'Brunhilde', 'BBi')
INSERT INTO Musiker VALUES (75)
INSERT INTO Substitut(OMitglID, MusikerID) VALUES (75, 65)

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Nolde', 'Emil', 'EmN')
INSERT INTO Musiker VALUES (76)
INSERT INTO Substitut(OMitglID, MusikerID) VALUES (76, 65)

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Ostermann', 'Olga', 'OlO')
INSERT INTO Musiker VALUES (77)
INSERT INTO Substitut(OMitglID, MusikerID) VALUES (77, 65)

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Paradies', 'Udo', 'UdP')
INSERT INTO Musiker VALUES (78)
INSERT INTO Substitut(OMitglID, MusikerID) VALUES (78, 68)

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Schulte', 'Tobias', 'ToS')
INSERT INTO Musiker VALUES (79)
INSERT INTO Substitut(OMitglID, MusikerID) VALUES (79, 70)

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Zaccia', 'Claude', 'ClZ')
INSERT INTO Musiker VALUES (80)
INSERT INTO Substitut(OMitglID, MusikerID) VALUES (80, 70)
COMMIT
go

-- 5 Musiker und 5 Substitute fuer Schlagwerk
INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel, Strasse, Hausnr, PLZ, Ort)
  VALUES ('Bummer', 'Aphrodite', 'ApB', 'Mozartgasse', '15', 14770, 'Brandenburg a.d. Havel')
INSERT INTO Musiker VALUES (81)
INSERT INTO AngestellterMusiker (OMitglID, GebDatum, GebOrt, BLZ, Kontonr, Anstellung,
        IstSolist, IstStimmfuehrer, StimmgrKuerzel) VALUES
        (81, '12-SEP-1958', 'Madrid', 16040000, 3443339237, '01-JAN-2003', 0, 1, 'Schlagwerk')

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel, Strasse, Hausnr, PLZ, Ort)
  VALUES ('Polter', 'Nicola', 'NiP', 'Raabeplatz', '8', 10587, 'Berlin')
INSERT INTO Musiker VALUES (82)
INSERT INTO AngestellterMusiker (OMitglID, GebDatum, GebOrt, BLZ, Kontonr, Anstellung,
        IstSolist, IstStimmfuehrer, StimmgrKuerzel) VALUES
        (82, '27-OCT-1949', 'Birmingham', 13061078, 7575885553, '15-SEP-2000', 0, 1, 'Schlagwerk')

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Dr�ge', 'Doris', 'DoD')
INSERT INTO Musiker VALUES (83)
INSERT INTO AngestellterMusiker (OMitglID, BLZ, Kontonr, Anstellung,
        IstSolist, IstStimmfuehrer, StimmgrKuerzel) 
    VALUES (83, 12070000, 3688874577, '01-JAN-2005', 1, 0, 'Schlagwerk')

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Habicht', 'Hannah', 'HaH')
INSERT INTO Musiker VALUES (84)
INSERT INTO AngestellterMusiker (OMitglID, BLZ, Kontonr, Anstellung,
        IstSolist, IstStimmfuehrer, StimmgrKuerzel) 
    VALUES (84, 37060590, 2233333771, '01-JUL-2003', 0, 1, 'Schlagwerk')

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Schr�der', 'Wilfried', 'WiS')
INSERT INTO Musiker VALUES (85)
INSERT INTO AngestellterMusiker (OMitglID, BLZ, Kontonr, Anstellung,
        IstSolist, IstStimmfuehrer, StimmgrKuerzel) 
    VALUES (85, 37060590, 3459987912, '01-JAN-2003', 0, 0, 'Schlagwerk')

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Lange', 'Nils', 'NiL')
INSERT INTO Musiker VALUES (86)
INSERT INTO Substitut(OMitglID, MusikerID) VALUES (86, 85)

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('M�del', 'Roman', 'RM�')
INSERT INTO Musiker VALUES (87)
INSERT INTO Substitut(OMitglID, MusikerID) VALUES (87, 83)

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Qing', 'Chen', 'ChQ')
INSERT INTO Musiker VALUES (88)
INSERT INTO Substitut(OMitglID, MusikerID) VALUES (88, 82)

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Irrwald', 'Oswald', 'OsI')
INSERT INTO Musiker VALUES (89)
INSERT INTO Substitut(OMitglID, MusikerID) VALUES (89, 82)

INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Bl�tterwald', 'Ramona', 'RaB')
INSERT INTO Musiker VALUES (90)
INSERT INTO Substitut(OMitglID, MusikerID) VALUES (90, 81)
COMMIT
go

-- Dirigent, der die spezifischen Besetzungen definiert hat
INSERT INTO Orchestermitglied(Name, Vorname, Kuerzel) VALUES ('Luftikus', 'Bertram', 'BeL')
INSERT INTO FestgelegtVon(BesID, OMitglID) VALUES (1, 91)
INSERT INTO FestgelegtVon(BesID, OMitglID) VALUES (3, 91)
INSERT INTO FestgelegtVon(BesID, OMitglID) VALUES (4, 91)
COMMIT
go

-- Punktekonten -- Punktekonto(OMitglID, Jahr, Monat, Punktestand)
INSERT INTO Punktekonto VALUES (1, 2010, 12, 35)
INSERT INTO Punktekonto VALUES (2, 2010, 12, 38)
INSERT INTO Punktekonto VALUES (3, 2010, 12, 31)
INSERT INTO Punktekonto VALUES (4, 2010, 12, 32)
INSERT INTO Punktekonto VALUES (5, 2010, 12, 34)
INSERT INTO Punktekonto VALUES (6, 2010, 12, 39)
INSERT INTO Punktekonto VALUES (7, 2010, 12, 42)
INSERT INTO Punktekonto VALUES (8, 2010, 12, 44)
INSERT INTO Punktekonto VALUES (9, 2010, 12, 43)
INSERT INTO Punktekonto VALUES (10, 2010, 12, 29)
INSERT INTO Punktekonto VALUES (11, 2010, 12, 30)
INSERT INTO Punktekonto VALUES (12, 2010, 12, 33)
INSERT INTO Punktekonto VALUES (13, 2010, 12, 33)
INSERT INTO Punktekonto VALUES (14, 2010, 12, 33)
INSERT INTO Punktekonto VALUES (15, 2010, 12, 35)
INSERT INTO Punktekonto VALUES (16, 2010, 12, 35)
INSERT INTO Punktekonto VALUES (17, 2010, 12, 34)
INSERT INTO Punktekonto VALUES (18, 2010, 12, 38)
INSERT INTO Punktekonto VALUES (19, 2010, 12, 38)
INSERT INTO Punktekonto VALUES (20, 2010, 12, 39)
INSERT INTO Punktekonto VALUES (21, 2010, 12, 43)
INSERT INTO Punktekonto VALUES (22, 2010, 12, 30)
INSERT INTO Punktekonto VALUES (23, 2010, 12, 34)
INSERT INTO Punktekonto VALUES (24, 2010, 12, 32)
INSERT INTO Punktekonto VALUES (25, 2010, 12, 28)
INSERT INTO Punktekonto VALUES (26, 2010, 12, 44)
INSERT INTO Punktekonto VALUES (27, 2010, 12, 33)
INSERT INTO Punktekonto VALUES (28, 2010, 12, 33)
INSERT INTO Punktekonto VALUES (29, 2010, 12, 33)
INSERT INTO Punktekonto VALUES (30, 2010, 12, 32)
INSERT INTO Punktekonto VALUES (31, 2010, 12, 30)
INSERT INTO Punktekonto VALUES (32, 2010, 12, 30)
INSERT INTO Punktekonto VALUES (41, 2010, 12, 30)
INSERT INTO Punktekonto VALUES (42, 2010, 12, 35)
INSERT INTO Punktekonto VALUES (43, 2010, 12, 35)
INSERT INTO Punktekonto VALUES (44, 2010, 12, 35)
INSERT INTO Punktekonto VALUES (45, 2010, 12, 39)
INSERT INTO Punktekonto VALUES (46, 2010, 12, 39)
INSERT INTO Punktekonto VALUES (47, 2010, 12, 35)
INSERT INTO Punktekonto VALUES (48, 2010, 12, 35)
INSERT INTO Punktekonto VALUES (49, 2010, 12, 39)
INSERT INTO Punktekonto VALUES (50, 2010, 12, 30)
INSERT INTO Punktekonto VALUES (51, 2010, 12, 32)
INSERT INTO Punktekonto VALUES (52, 2010, 12, 32)
INSERT INTO Punktekonto VALUES (53, 2010, 12, 32)
INSERT INTO Punktekonto VALUES (61, 2010, 12, 31)
INSERT INTO Punktekonto VALUES (62, 2010, 12, 31)
INSERT INTO Punktekonto VALUES (63, 2010, 12, 39)
INSERT INTO Punktekonto VALUES (64, 2010, 12, 43)
INSERT INTO Punktekonto VALUES (65, 2010, 12, 42)
INSERT INTO Punktekonto VALUES (66, 2010, 12, 44)
INSERT INTO Punktekonto VALUES (67, 2010, 12, 44)
INSERT INTO Punktekonto VALUES (68, 2010, 12, 33)
INSERT INTO Punktekonto VALUES (69, 2010, 12, 38)
INSERT INTO Punktekonto VALUES (70, 2010, 12, 38)
INSERT INTO Punktekonto VALUES (81, 2010, 12, 50)
INSERT INTO Punktekonto VALUES (82, 2010, 12, 48)
INSERT INTO Punktekonto VALUES (83, 2010, 12, 36)
INSERT INTO Punktekonto VALUES (84, 2010, 12, 31)
INSERT INTO Punktekonto VALUES (85, 2010, 12, 31)
COMMIT
go
INSERT INTO Punktekonto VALUES (1, 2011, 1, 35)
INSERT INTO Punktekonto VALUES (2, 2011, 1, 35)
INSERT INTO Punktekonto VALUES (3, 2011, 1, 35)
INSERT INTO Punktekonto VALUES (4, 2011, 1, 33)
INSERT INTO Punktekonto VALUES (5, 2011, 1, 31)
INSERT INTO Punktekonto VALUES (6, 2011, 1, 22)
INSERT INTO Punktekonto VALUES (7, 2011, 1, 24)
INSERT INTO Punktekonto VALUES (8, 2011, 1, 21)
INSERT INTO Punktekonto VALUES (9, 2011, 1, 20)
INSERT INTO Punktekonto VALUES (10, 2011, 1, 32)
INSERT INTO Punktekonto VALUES (11, 2011, 1, 31)
INSERT INTO Punktekonto VALUES (12, 2011, 1, 31)
INSERT INTO Punktekonto VALUES (13, 2011, 1, 31)
INSERT INTO Punktekonto VALUES (14, 2011, 1, 31)
INSERT INTO Punktekonto VALUES (15, 2011, 1, 32)
INSERT INTO Punktekonto VALUES (16, 2011, 1, 32)
INSERT INTO Punktekonto VALUES (17, 2011, 1, 32)
INSERT INTO Punktekonto VALUES (18, 2011, 1, 32)
INSERT INTO Punktekonto VALUES (19, 2011, 1, 32)
INSERT INTO Punktekonto VALUES (20, 2011, 1, 32)
INSERT INTO Punktekonto VALUES (21, 2011, 1, 32)
INSERT INTO Punktekonto VALUES (22, 2011, 1, 16)
INSERT INTO Punktekonto VALUES (23, 2011, 1, 17)
INSERT INTO Punktekonto VALUES (24, 2011, 1, 22)
INSERT INTO Punktekonto VALUES (25, 2011, 1, 31)
INSERT INTO Punktekonto VALUES (26, 2011, 1, 30)
INSERT INTO Punktekonto VALUES (27, 2011, 1, 30)
INSERT INTO Punktekonto VALUES (28, 2011, 1, 30)
INSERT INTO Punktekonto VALUES (29, 2011, 1, 30)
INSERT INTO Punktekonto VALUES (30, 2011, 1, 27)
INSERT INTO Punktekonto VALUES (31, 2011, 1, 27)
INSERT INTO Punktekonto VALUES (32, 2011, 1, 26)
INSERT INTO Punktekonto VALUES (41, 2011, 1, 25)
INSERT INTO Punktekonto VALUES (42, 2011, 1, 22)
INSERT INTO Punktekonto VALUES (43, 2011, 1, 29)
INSERT INTO Punktekonto VALUES (44, 2011, 1, 30)
INSERT INTO Punktekonto VALUES (45, 2011, 1, 30)
INSERT INTO Punktekonto VALUES (46, 2011, 1, 30)
INSERT INTO Punktekonto VALUES (47, 2011, 1, 30)
INSERT INTO Punktekonto VALUES (48, 2011, 1, 27)
INSERT INTO Punktekonto VALUES (49, 2011, 1, 27)
INSERT INTO Punktekonto VALUES (50, 2011, 1, 27)
INSERT INTO Punktekonto VALUES (51, 2011, 1, 25)
INSERT INTO Punktekonto VALUES (52, 2011, 1, 25)
INSERT INTO Punktekonto VALUES (53, 2011, 1, 29)
INSERT INTO Punktekonto VALUES (61, 2011, 1, 30)
INSERT INTO Punktekonto VALUES (62, 2011, 1, 32)
INSERT INTO Punktekonto VALUES (63, 2011, 1, 32)
INSERT INTO Punktekonto VALUES (64, 2011, 1, 32)
INSERT INTO Punktekonto VALUES (65, 2011, 1, 31)
INSERT INTO Punktekonto VALUES (66, 2011, 1, 31)
INSERT INTO Punktekonto VALUES (67, 2011, 1, 31)
INSERT INTO Punktekonto VALUES (68, 2011, 1, 31)
INSERT INTO Punktekonto VALUES (69, 2011, 1, 34)
INSERT INTO Punktekonto VALUES (70, 2011, 1, 33)
INSERT INTO Punktekonto VALUES (81, 2011, 1, 28)
INSERT INTO Punktekonto VALUES (82, 2011, 1, 26)
INSERT INTO Punktekonto VALUES (83, 2011, 1, 27)
INSERT INTO Punktekonto VALUES (84, 2011, 1, 27)
INSERT INTO Punktekonto VALUES (85, 2011, 1, 31)

INSERT INTO Punktekonto VALUES (1, 2010, 11, 31)
INSERT INTO Punktekonto VALUES (1, 2010, 10, 41)
INSERT INTO Punktekonto VALUES (1, 2010, 9, 36)
INSERT INTO Punktekonto VALUES (1, 2010, 8, 34)
INSERT INTO Punktekonto VALUES (1, 2010, 7, 22)
INSERT INTO Punktekonto VALUES (1, 2010, 6, 21)
INSERT INTO Punktekonto VALUES (1, 2010, 5, 33)
INSERT INTO Punktekonto VALUES (1, 2010, 4, 39)
INSERT INTO Punktekonto VALUES (1, 2010, 3, 42)
INSERT INTO Punktekonto VALUES (1, 2010, 2, 41)
INSERT INTO Punktekonto VALUES (1, 2010, 1, 31)

INSERT INTO Punktekonto VALUES (1, 2009, 12, 33)
INSERT INTO Punktekonto VALUES (1, 2009, 11, 37)
INSERT INTO Punktekonto VALUES (1, 2009, 10, 32)
INSERT INTO Punktekonto VALUES (1, 2009, 9, 39)
INSERT INTO Punktekonto VALUES (1, 2009, 8, 31)
INSERT INTO Punktekonto VALUES (1, 2009, 7, 29)
INSERT INTO Punktekonto VALUES (1, 2009, 6, 27)
INSERT INTO Punktekonto VALUES (1, 2009, 5, 39)
INSERT INTO Punktekonto VALUES (1, 2009, 4, 34)
INSERT INTO Punktekonto VALUES (1, 2009, 3, 45)
INSERT INTO Punktekonto VALUES (1, 2009, 2, 49)
INSERT INTO Punktekonto VALUES (1, 2009, 1, 32)

INSERT INTO Punktekonto VALUES (1, 2008, 12, 36)
INSERT INTO Punktekonto VALUES (1, 2008, 11, 32)
INSERT INTO Punktekonto VALUES (1, 2008, 10, 32)
INSERT INTO Punktekonto VALUES (1, 2008, 9, 39)
INSERT INTO Punktekonto VALUES (1, 2008, 8, 38)
INSERT INTO Punktekonto VALUES (1, 2008, 7, 23)
INSERT INTO Punktekonto VALUES (1, 2008, 6, 29)
INSERT INTO Punktekonto VALUES (1, 2008, 5, 30)
INSERT INTO Punktekonto VALUES (1, 2008, 4, 39)
INSERT INTO Punktekonto VALUES (1, 2008, 3, 42)
INSERT INTO Punktekonto VALUES (1, 2008, 2, 41)
INSERT INTO Punktekonto VALUES (1, 2008, 1, 38)

INSERT INTO Punktekonto VALUES (31, 2010, 11, 51)
INSERT INTO Punktekonto VALUES (31, 2010, 10, 31)
INSERT INTO Punktekonto VALUES (31, 2010, 9, 39)
INSERT INTO Punktekonto VALUES (31, 2010, 8, 33)
INSERT INTO Punktekonto VALUES (31, 2010, 7, 29)
INSERT INTO Punktekonto VALUES (31, 2010, 6, 24)
INSERT INTO Punktekonto VALUES (31, 2010, 5, 38)
INSERT INTO Punktekonto VALUES (31, 2010, 4, 35)
INSERT INTO Punktekonto VALUES (31, 2010, 3, 28)
INSERT INTO Punktekonto VALUES (31, 2010, 2, 47)
INSERT INTO Punktekonto VALUES (31, 2010, 1, 33)

INSERT INTO Punktekonto VALUES (31, 2009, 12, 31)
INSERT INTO Punktekonto VALUES (31, 2009, 11, 27)
INSERT INTO Punktekonto VALUES (31, 2009, 10, 26)
INSERT INTO Punktekonto VALUES (31, 2009, 9, 31)
INSERT INTO Punktekonto VALUES (31, 2009, 8, 38)
INSERT INTO Punktekonto VALUES (31, 2009, 7, 34)
INSERT INTO Punktekonto VALUES (31, 2009, 6, 32)
INSERT INTO Punktekonto VALUES (31, 2009, 5, 37)
INSERT INTO Punktekonto VALUES (31, 2009, 4, 32)
INSERT INTO Punktekonto VALUES (31, 2009, 3, 49)
INSERT INTO Punktekonto VALUES (31, 2009, 2, 47)
INSERT INTO Punktekonto VALUES (31, 2009, 1, 42)
COMMIT
go


-- Gespielte Instrumente der Streicher
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (1,1)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (1,2)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (1,3)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (1,4)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (1,5)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (1,6)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (1,7)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (1,8)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (1,9)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (1,10)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (2,6)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (2,7)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (2,8)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (2,9)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (2,10)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (3,6)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (3,7)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (3,8)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (3,9)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (3,10)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (5,2)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (5,3)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (5,4)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (5,5)

INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (2,11)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (2,12)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (2,13)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (2,14)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (2,15)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (2,16)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (2,17)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (2,18)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (2,19)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (2,20)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (2,21)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (2,22)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (2,23)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (3,21)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (3,22)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (3,23)

INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (3,12)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (3,13)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (3,14)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (3,15)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (4,17)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (4,18)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (4,19)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (4,20)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (4,23)

INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (4,24)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (4,28)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (4,29)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (4,30)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (4,31)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (4,32)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (5,32)

INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (5,24)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (5,25)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (5,26)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (5,27)

-- Gespielte Instrumente der Holzblaeser
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (6,41)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (6,42)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (6,43)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (6,44)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (6,45)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (7,41)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (7,42)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (7,43)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (7,44)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (7,45)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (8,44)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (8,45)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (8,46)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (8,47)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (9,44)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (9,45)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (9,46)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (9,47)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (10,48)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (10,49)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (10,50)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (10,51)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (11,48)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (11,49)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (11,50)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (11,51)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (12,48)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (12,49)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (12,50)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (12,51)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (13,51)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (13,52)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (13,53)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (14,52)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (14,53)

-- Gespielte Instrumente der Blechblaeser
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (15,61)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (15,62)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (15,63)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (16,61)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (16,62)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (16,63)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (17,64)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (17,65)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (17,66)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (18,67)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (18,68)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (18,69)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (19,67)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (19,68)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (19,69)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (20,69)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (20,70)


-- Gespielte Instrumente beim Schlagwerk
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (21,81)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (22,81)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (22,82)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (23,83)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (24,84)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (25,84)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (26,85)
INSERT INTO SpielbarVon(InstrID,OMitglID) VALUES (23,85)
COMMIT
go


-- Diensteinteilung f�r Proben und Auff�hrungen Cosi fan tutte
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (1, 1, 1, 0, 1, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (1, 2, 1, 0, 0, null, 'y' )
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (1, 3, 1, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (1, 4, 1, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (1, 5, 1, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (1, 6, 1, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (1, 7, 1, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (1, 37, 1, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (1, 9, 2, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (1, 10, 2, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (1, 11, 2, 0, 1, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (1, 17, 2, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (1, 18, 2, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (1, 19, 2, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (1, 20, 2, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (1, 16, 2, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (1, 12, 3, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (1, 13, 3, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (1, 14, 3, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (1, 15, 3, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (1, 21, 3, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (1, 22, 3, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (1, 23, 4, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (1, 24, 4, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (1, 34, 4, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (1, 29, 4, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (1, 25, 5, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (1, 26, 5, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (1, 32, 4, 1, 0, null, 'y')

INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (1, 42, 6, 0, 1, 1, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (1, 43, 6, 0, 0, 2, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (1, 45, 8, 0, 0, 1, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (1, 47, 8, 0, 0, 2, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (1, 48, 10, 0, 0, 1, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (1, 50, 10, 0, 0, 2, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (1, 52, 13, 0, 0, 1, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (1, 53, 13, 0, 0, 2, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (1, 54, 6, 0, 0, null, 'n')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (1, 62, 15, 0, 1, 1, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (1, 74, 15, 0, 0, 2, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (1, 64, 17, 0, 0, 1, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (1, 66, 17, 0, 0, 2, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (1, 65, 17, 1, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (1, 81, 21, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (1, 82, 21, 1, 0, null, 'n')
COMMIT
go

-- bei den anderen Proben und Auff�hrungen die gleiche Besetzung ohne Ersatzspieler
INSERT INTO TeiltEin  
 SELECT 2, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt
   FROM TeiltEin
  WHERE DienstID = 1

INSERT INTO TeiltEin  
 SELECT 4, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt
   FROM TeiltEin
  WHERE DienstID = 1

INSERT INTO TeiltEin  
 SELECT 5, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt
   FROM TeiltEin
  WHERE DienstID = 1

INSERT INTO TeiltEin  
 SELECT 6, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt
   FROM TeiltEin
  WHERE DienstID = 1
COMMIT
go

-- bei den Auff�hrungen von Cosi fan tutte wurde kein Ersatzspieler eingesetzt
update TeiltEin
   set Gespielt = 'n'
 where DienstID > 3 and DienstID <= 6 and AlsErsatz = 1
COMMIT
go



-- Diensteinteilung f�r Proben und Auff�hrungen Manon
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (7, 1, 1, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (7, 2, 1, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (7, 3, 1, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (7, 4, 1, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (7, 5, 1, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (7, 6, 1, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (7, 7, 1, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (7, 36, 1, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (7, 11, 2, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (7, 16, 2, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (7, 17, 2, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (7, 18, 2, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (7, 19, 2, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (7, 20, 2, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (7, 9, 2, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (7, 8, 2, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (7, 12, 3, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (7, 13, 3, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (7, 14, 3, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (7, 15, 3, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (7, 21, 3, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (7, 22, 3, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (7, 23, 4, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (7, 28, 4, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (7, 29, 4, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (7, 30, 4, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (7, 31, 4, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (7, 32, 4, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (7, 38, 5, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (7, 25, 5, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (7, 26, 5, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (7, 27, 5, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (7, 35, 3, 1, 0, null, 'n')

INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (7, 42, 6, 0, 1, 1, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (7, 56, 6, 0, 0, 2, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (7, 45, 6, 0, 0, 3, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (7, 43, 8, 0, 0, 1, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (7, 58, 8, 0, 0, 2, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (7, 47, 9, 0, 0, 1, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (7, 49, 10, 0, 0, 1, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (7, 51, 10, 0, 0, 2, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (7, 50, 11, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (7, 52, 13, 0, 0, 1, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (7, 53, 13, 0, 0, 2, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (7, 48, 10, 1, 0, null, 'n')

INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (7, 61, 15, 0, 1, 1, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (7, 62, 15, 0, 0, 2, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (7, 63, 15, 0, 0, 3, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (7, 64, 17, 0, 0, 1, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (7, 65, 17, 0, 0, 2, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (7, 66, 17, 0, 0, 3, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (7, 67, 18, 0, 0, 1, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (7, 78, 18, 0, 0, 2, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (7, 69, 18, 0, 0, 3, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (7, 68, 18, 1, 0, null, 'n')

INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (7, 81, 21, 0, 1, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (7, 82, 22, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (7, 83, 23, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (7, 85, 23, 1, 0, null, 'n')

-- bei den anderen Proben und Auff�hrungen die gleiche Besetzung ohne Ersatzspieler
INSERT INTO TeiltEin  
 SELECT 8, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt
   FROM TeiltEin
  WHERE DienstID = 7

INSERT INTO TeiltEin  
 SELECT 11, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt
   FROM TeiltEin
  WHERE DienstID = 7

INSERT INTO TeiltEin  
 SELECT 12, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt
   FROM TeiltEin
  WHERE DienstID = 7

INSERT INTO TeiltEin  
 SELECT 13, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt
   FROM TeiltEin
  WHERE DienstID = 7
COMMIT
go



-- Diensteinteilung f�r Hofkapelle
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (14, 2, 1, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (14, 5, 1, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (14, 8, 1, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (14, 9, 1, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (14, 13, 2, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (14, 15, 2, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (14, 17, 2, 0, 0, null, 'n')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (14, 18, 2, 1, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (14, 30, 4, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (14, 31, 4, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (14, 24, 5, 0, 0, null, 'y')


-- Diensteinteilung f�r Trompeten-Vorspiel
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (9, 64, 17, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (9, 65, 17, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (9, 66, 17, 0, 0, null, 'y')

-- Diensteinteilung f�r Sitzung Blechblaeser
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (10, 61, 15, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (10, 62, 15, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (10, 63, 15, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (10, 64, 17, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (10, 65, 17, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (10, 66, 17, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (10, 67, 18, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (10, 68, 18, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (10, 69, 18, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (10, 70, 20, 0, 0, null, 'y')

-- Diensteinteilung f�r Sitzung der Diensteinteilungs-Verantwortlichen
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (3, 84, 24, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (3, 64, 17, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (3, 50, 11, 0, 0, null, 'y')
INSERT INTO TeiltEin (DienstID, OMitglID, InstrID, AlsErsatz, AlsStimmfuehrer, Position, Gespielt)
  VALUES (3, 11, 2, 0, 0, null, 'y')
COMMIT
go

