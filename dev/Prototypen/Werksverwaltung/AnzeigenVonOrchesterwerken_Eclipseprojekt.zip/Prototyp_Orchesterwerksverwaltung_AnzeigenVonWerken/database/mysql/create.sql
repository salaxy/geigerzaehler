﻿/*==============================================================*/
/* DBMS name:      MySQL 5.0                                    */
/* Created on:     09.03.2011 19:40:23                          */
/*==============================================================*/
/* create database */
  /* create database IF NOT EXISTS concerto CHARACTER SET latin1; */
/*
  CREATE SCHEMA `concerto` DEFAULT CHARACTER SET latin1 COLLATE latin1_german1_ci ;
  use concerto;
---------------- */

/*==============================================================*/
/* Table: AngestellterMusiker                                   */
/*==============================================================*/
create table AngestellterMusiker
(
   OMitglID             integer      not null,
   GebDatum             date,
   GebOrt               varchar(30),
   BLZ                  numeric(8,0) not null,
   Kontonr              numeric(10,0) not null,
   Anstellung           date not null,
   IstSolist            bool not null,
   IstStimmfuehrer      bool not null,
   StimmgrKuerzel       varchar(10) not null,
   primary key (OMitglID)
) engine=InnoDB;

/*==============================================================*/
/* Table: Bank                                                  */
/*==============================================================*/
create table Bank
(
   BLZ                  numeric(8,0) not null,
   Kreditinstitut       varchar(40) not null,
   primary key (BLZ)
) engine=InnoDB;

/*==============================================================*/
/* Table: Benutzt                                               */
/*==============================================================*/
create table Benutzt
(
   BesID                integer not null,
   InstrID              integer not null,
   Anzahl               numeric(3,0),
   GespieltVon          varchar(20),
   primary key (BesID, InstrID)
) engine=InnoDB;

/*==============================================================*/
/* Table: Besetzung                                             */
/*==============================================================*/
create table Besetzung
(
   BesID                integer not null auto_increment,
   Typ                  varchar(30) not null,
   WerkID               integer,
   primary key (BesID)
) engine=InnoDB;

/*==============================================================*/
/* Table: Dienst                                                */
/*==============================================================*/
create table Dienst
(
   DienstID             integer(12) not null auto_increment,
   Beginn               datetime not null,
   Tageszeit            char(1) not null,
   Dauer                numeric(5,0) not null,
   Name                 varchar(40),
   Bemerkung            varchar(256),
   Diensttyp            varchar(26) not null,
   BesID                integer,
   PunkteID             integer(9),
   primary key (DienstID)
) engine=InnoDB;

/*==============================================================*/
/* Table: Diensttyp                                             */
/*==============================================================*/
create table Diensttyp
(
   Name                 varchar(26) not null,
   PunkteID             integer(9)  not null,
   primary key (Name)
) engine=InnoDB;

/*==============================================================*/
/* Table: FestgelegtVon                                         */
/*==============================================================*/
create table FestgelegtVon
(
   BesID                integer not null,
   OMitglID             integer not null,
   primary key (BesID)
) engine=InnoDB;

/*==============================================================*/
/* Table: Instrumententyp                                       */
/*==============================================================*/
create table Instrumententyp
(
   InstrID              integer not null auto_increment,
   Name                 varchar(30) not null,
   Kuerzel              char(5),
   Art                  char(6) not null,
   StimmgrKuerzel       varchar(10) not null,
   primary key (InstrID)
) engine=InnoDB;

/*==============================================================*/
/* Table: Musiker                                               */
/*==============================================================*/
create table Musiker
(
   OMitglID             integer not null,
   primary key (OMitglID)
) engine=InnoDB;

/*==============================================================*/
/* Table: Orchestermitglied                                     */
/*==============================================================*/
create table Orchestermitglied
(
   OMitglID             integer not null auto_increment,
   Name                 varchar(30) not null,
   Vorname              varchar(30) not null,
   Kuerzel              char(3) not null,
   Strasse              varchar(40),
   Hausnr               varchar(10),
   PLZ                  numeric(5,0),
   Ort                  varchar(30),
   primary key (OMitglID)
) engine=InnoDB;

/*==============================================================*/
/* Table: Orchesterwerk                                         */
/*==============================================================*/
create table Orchesterwerk
(
   WerkID               integer not null auto_increment,
   Typ                  varchar(30) not null,
   Name                 varchar(50) not null,
   Komponist            varchar(50) not null,
   Dauer                numeric(3,0) not null,
   NotenDa              bool not null,
   primary key (WerkID)
) engine=InnoDB;

/*==============================================================*/
/* Table: Punkte                                                */
/*==============================================================*/
create table Punkte
(
   PunkteID             integer(9) not null auto_increment,
   PktStimmfuehrer      numeric(2,0),
   PktTutti             numeric(2,0) not null,
   PktSolist            numeric(2,0),
   PktErsatz            numeric(2,0),
   primary key (PunkteID)
) engine=InnoDB;

/*==============================================================*/
/* Table: Punktekonto                                           */
/*==============================================================*/
create table Punktekonto
(
   OMitglID             integer not null,
   Jahr                 numeric(4,0) not null,
   Monat                numeric(2,0) not null,
   Punktestand          numeric(5,0) not null default 0,
   primary key (OMitglID, Jahr, Monat)
) engine=InnoDB;

/*==============================================================*/
/* Table: SpielbarVon                                           */
/*==============================================================*/
create table SpielbarVon
(
   InstrID              integer      not null,
   OMitglID             integer      not null,
   primary key (InstrID, OMitglID)
) engine=InnoDB;

/*==============================================================*/
/* Table: Stimmgruppe                                           */
/*==============================================================*/
create table Stimmgruppe
(
   Kuerzel              varchar(10) not null,
   Name                 varchar(15) not null,
   primary key (Kuerzel)
) engine=InnoDB;

/*==============================================================*/
/* Table: Substitut                                             */
/*==============================================================*/
create table Substitut
(
   OMitglID             integer      not null,
   MusikerID            integer      not null,
   primary key (OMitglID)
) engine=InnoDB;

/*==============================================================*/
/* Table: TeiltEin                                              */
/*==============================================================*/
create table TeiltEin
(
   DienstID             integer(12)  not null,
   OMitglID             integer      not null,
   InstrID              integer      not null,
   AlsErsatz            bool not null,
   AlsStimmfuehrer      bool not null,
   Position             numeric(1,0),
   Gespielt             char(1),
   primary key (DienstID, OMitglID)
) engine=InnoDB;

/*==============================================================*/
/* Table: WunschVon                                             */
/*==============================================================*/
create table WunschVon
(
   DienstID             integer(12) not null,
   OMitglID             integer     not null,
   IstPositiv           bool not null,
   primary key (DienstID, OMitglID)
) engine=InnoDB;

alter table AngestellterMusiker add constraint Angestellt_395145422 foreign key (OMitglID)
      references Musiker (OMitglID) on delete restrict on update restrict;

alter table AngestellterMusiker add constraint Angestellt_411145479 foreign key (StimmgrKuerzel)
      references Stimmgruppe (Kuerzel) on delete restrict on update restrict;

alter table AngestellterMusiker add constraint Angestellt_427145536 foreign key (BLZ)
      references Bank (BLZ) on delete restrict on update restrict;

alter table Benutzt add constraint Benutzt_235144852 foreign key (BesID)
      references Besetzung (BesID) on delete restrict on update restrict;

alter table Benutzt add constraint Benutzt_251144909 foreign key (InstrID)
      references Instrumententyp (InstrID) on delete restrict on update restrict;

alter table Besetzung add constraint Besetzung_WerkID_139144510 foreign key (WerkID)
      references Orchesterwerk (WerkID) on delete restrict on update restrict;

alter table Dienst add constraint Dienst_683146448 foreign key (Diensttyp)
      references Diensttyp (Name) on delete restrict on update restrict;

alter table Dienst add constraint Dienst_699146505 foreign key (BesID)
      references Besetzung (BesID) on delete restrict on update restrict;

alter table Dienst add constraint Dienst_715146562 foreign key (PunkteID)
      references Punkte (PunkteID) on delete restrict on update restrict;

alter table Diensttyp add constraint Diensttyp_635146277 foreign key (PunkteID)
      references Punkte (PunkteID) on delete restrict on update restrict;

alter table FestgelegtVon add constraint Festgelegt_299145080 foreign key (BesID)
      references Besetzung (BesID) on delete restrict on update restrict;

alter table FestgelegtVon add constraint Festgelegt_315145137 foreign key (OMitglID)
      references Orchestermitglied (OMitglID) on delete restrict on update restrict;

alter table Instrumententyp add constraint Instrument_Stimmg_203144738 foreign key (StimmgrKuerzel)
      references Stimmgruppe (Kuerzel) on delete restrict on update restrict;

alter table Musiker add constraint Musiker_347145251 foreign key (OMitglID)
      references Orchestermitglied (OMitglID) on delete restrict on update restrict;

alter table Punktekonto add constraint Punktekont_587146106 foreign key (OMitglID)
      references AngestellterMusiker (OMitglID) on delete restrict on update restrict;

alter table SpielbarVon add constraint SpielbarVo_507145821 foreign key (InstrID)
      references Instrumententyp (InstrID) on delete restrict on update restrict;

alter table SpielbarVon add constraint SpielbarVo_523145878 foreign key (OMitglID)
      references AngestellterMusiker (OMitglID) on delete restrict on update restrict;

alter table Substitut add constraint Substitut_459145650 foreign key (OMitglID)
      references Musiker (OMitglID) on delete restrict on update restrict;

alter table Substitut add constraint Substitut_475145707 foreign key (MusikerID)
      references AngestellterMusiker (OMitglID) on delete restrict on update restrict;

alter table TeiltEin add constraint TeiltEin_811146904 foreign key (DienstID)
      references Dienst (DienstID) on delete restrict on update restrict;

alter table TeiltEin add constraint TeiltEin_827146961 foreign key (OMitglID)
      references Musiker (OMitglID) on delete restrict on update restrict;

alter table TeiltEin add constraint TeiltEin_843147018 foreign key (InstrID)
      references Instrumententyp (InstrID) on delete restrict on update restrict;

alter table WunschVon add constraint WunschVon_747146676 foreign key (DienstID)
      references Dienst (DienstID) on delete restrict on update restrict;

alter table WunschVon add constraint WunschVon_763146733 foreign key (OMitglID)
      references AngestellterMusiker (OMitglID) on delete restrict on update restrict;
