--
-- Selbstverwaltetes Orchester Concerto
-- Susanne Busse, Dezember 2010
--
-- Skript zum Loeschen des Datenbankschemas
--


-- ggf. Loeschen der Tabellen
drop table TeiltEin;
drop table WunschVon;
drop table Dienst;
drop table Diensttyp;
drop table Punkte;
drop table Punktekonto;
drop table SpielbarVon;
drop table Substitut;
drop table AngestellterMusiker;
drop table Bank;
drop table Musiker;
drop table FestgelegtVon;
drop table Orchestermitglied;
drop table Benutzt;
drop table Instrumententyp;
drop table Stimmgruppe;
drop table Besetzung;
drop table Orchesterwerk;

