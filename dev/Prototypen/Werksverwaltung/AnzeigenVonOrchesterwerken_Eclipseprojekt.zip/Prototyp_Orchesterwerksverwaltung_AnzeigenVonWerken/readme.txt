/**
 * Grobstruktur des Projekts:
 * - src/		Quellcode (inkl. GUI, Persistenzschicht und deren Konfiguration)
 * - database/	Skripte zum Anlegen, F�llen und L�schen der Datenbank,
 *              f�r Sybase ASE und MySQL (falls lokal installiert)
 * - lib/ 		Ben�tigte Libraries f�r Hibernate und JDBC
 * - logs/		Verzeichnis der Logdaten des DB-Zugriffs (Hibernate)
 *              muss ggf. manuell geleert werden!
 *
 * Anleitung:
 * - Anlegen der Datenbank
 *   Skripte create.sql und insert.sql 
 *   in database/sybase im eigenen Sybase-DB-Bereich anlegen.
 * - Konfiguration der Persistenzschicht
 *   Die Konfigurationsdatei muss hibernate.cfg.xml heissen. Zur Benutzung von
 *   Sybase ist die Datei sybase-hibernate.cfg.xml entsprechen umzubenennen.
 *   Es sind die ersten drei Properties url, username und password anzupassen.
 * - Ausfuehren der Beispiel-Applikation.
 *   Eine Beispiel-Applikation zum Testen Ihrer Datenbank finden Sie de.fhb.orchester.example:
 *   OrchesterExampleAppication.java
 *   Ausf�hren als Java Application... 
 *   Achtung: Mindestens beim ersten Starten kann das Problem l�ngere Zeit 
 *   ben�tigen! Es geht dann aber ein Fenster auf, in dem der Rennstall
 *   ausgesucht werden kann, zu dem weitere Informationen angezeigt werden
 *   sollen
 * - Das Hauptprogramm der Schichtenarchitektur ist zu finden in de.fhb.orchester.gui.controller:
 *   Start.java
 *   Ausf�hren als Java Application... 
 *   
 * Zum Wechsel von Sybase zu einer lokalen MySQL-Datenbank ist folgendes zu tun
 * - Anlegen der Datenbank (vgl. Skripte unter database/mysql)
 * - Konfigurieren der hibernate.cfg.xml
 * - Wechsel der JDBC-Bibliothek:
 *   Anstelle von jconn2.jar ist das jar unter lib/jdbc-mysql einzubinden.
 * Bitte beachten Sie die Hinweise zu Sybase unter Moodle!
 *   
 * @author Susanne Busse, Gabrilee Schmidt
 */