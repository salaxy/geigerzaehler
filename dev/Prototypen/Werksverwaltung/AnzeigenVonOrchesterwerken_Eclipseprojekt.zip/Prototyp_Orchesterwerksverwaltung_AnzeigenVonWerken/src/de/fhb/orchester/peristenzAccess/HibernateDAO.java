/**
 * Implementiert Hibernate und stellt bestimmte Grundfunktionen zur Datenbank-Manipulation bereit
 */

package de.fhb.orchester.peristenzAccess;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import de.fhb.orchester.dbhibernate.util.HibernateUtil;

public class HibernateDAO<T> {
	private SessionFactory sessionFactory;
	private Session session;
	
	/**
	 * Default-Konstruktor
	 */
	public HibernateDAO() {
		try {
			sessionFactory =  HibernateUtil.getSessionFactory();
			session = sessionFactory.openSession();
		}
		catch(HibernateException e) { e.printStackTrace(); }
	}
	
	/**
	 * Aktuelle Session zurueckgeben
	 * @return Session
	 */
	protected Session getSession() {
		return session;
	}

	/**
	 * Neue Transaktion starten
	 */
	protected void startTransaction() {
		getSession().beginTransaction();
	}
	
	/**
	 * Transaktion schlie�en und ausfuehren
	 */
	protected void closeTransaction() {
		getSession().getTransaction().commit();
	}
	
	/**
	 * Transaktion rueckgaengig machen
	 */
	protected void rollbackTransaction() {
		getSession().getTransaction().rollback();
	}
	
	/**
	 * Datensatz hinzufuegen
	 * @param vo Value-Object
	 */
	public void insert(T vo) {
		try{
			startTransaction();
			getSession().save(vo);
			closeTransaction();
		}
		catch(HibernateException e) { rollbackTransaction(); e.printStackTrace(); }
	}
	
	/**
	 * Datensatz aktualisieren
	 * @param vo Value-Object
	 */
	public void update(T vo) {
		try{
			startTransaction();
			getSession().update(vo);
			closeTransaction();
		}
		catch(HibernateException e) { rollbackTransaction(); e.printStackTrace(); }
	}
	
	/**
	 * Datensatz loeschen
	 * @param vo Value-Object
	 */
	public void delete(T vo) {
		try{
			startTransaction();
			getSession().delete(vo);
			closeTransaction();
		}
		catch(HibernateException e) { rollbackTransaction(); e.printStackTrace(); }
	}
	
	/**
	 * Fuehrt ein HQL-Query aus und gibt die Ergebnismenge zurueck
	 * @param query HQL-Query
	 * @return Value-Objects
	 */
	public List<T> query(String query) {
		List<T> list = null;
		
		try{
			startTransaction();
			list = getSession().createQuery(query).list();
			closeTransaction();
		}
		catch(HibernateException e) { rollbackTransaction(); e.printStackTrace(); }

		return list;
	}
	
	/**
	 * Fuehrt ein HQL-Query aus und gibt ein einzelnes VO zurueck
	 * @param query HQL-Query
	 * @return Value-Objects
	 */
	public T queryUnique(String query) {
		T vo = null;
		Query q = null;
		
		try{
			startTransaction();
			q = getSession().createQuery(query);
			q.setMaxResults(1);
			vo = (T)q.uniqueResult();
			closeTransaction();
		}
		catch(HibernateException e) { rollbackTransaction(); e.printStackTrace(); }

		return vo;
	}
	
	/**
	 * Fuehrt ein HQL-Query aus
	 * @param query HQL-Query
	 */
	public void queryUpdate(String query) {
		try{
			startTransaction();
			getSession().createQuery(query).executeUpdate();
			closeTransaction();
		}
		catch(HibernateException e) { rollbackTransaction(); e.printStackTrace(); }
	}
	
	/**
	 * Bereitet ein HQL-Query vor, fuehrt es aus und gibt die Ergebnismenge zurueck	
	 * @param queryString HQL-Query
	 * @param params einzufuegende Parameter
	 * @return Value-Objects
	 */
	public List<T> preparedQuery(String queryString, String[] params) {
		List<T> list = null;
		Query query;
		int i = 0;
		
		try{
			startTransaction();
			query = getSession().createQuery(queryString);
			for(String s : params) query.setString(i++, s);
			list = query.list();
			closeTransaction();
		}
		catch(HibernateException e) { rollbackTransaction(); e.printStackTrace(); }

		return list;
	}
}
