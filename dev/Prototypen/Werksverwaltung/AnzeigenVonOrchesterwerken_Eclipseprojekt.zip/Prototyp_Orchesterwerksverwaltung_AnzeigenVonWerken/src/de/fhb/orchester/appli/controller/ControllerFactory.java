package de.fhb.orchester.appli.controller;

/**
 * 
 * Schnittstelle zum GUI (Controller)
 * Die ControllerFactory erzeugt Controller, so dass nur die Interfaces der Controller
 * der Applikation genutzt werden m�ssen.
 * 
 * GGf. muss die Factory noch so erweitert werden, dass verschiedene 
 * Controller der Applikation erzeugt werden k�nnen.
 * 
 * @author Gabriele Schmidt
 * @version 0.1 
 * @since 08.04.2011
 * 
 */

public class ControllerFactory {

//	public static MusikerverwaltungControllerInterface buildController() {
//        return new MusikerverwaltungControllerImpl();
//    }
	
	public static OrchesterwerksverwaltungControllerInterface buildWerksController() {
        return new OrchesterwerksverwaltungControllerImpl();
    }

}
