package de.fhb.orchester.gui.controller;

import de.fhb.orchester.gui.view.WerksGUIFrame;

/**
 * Ist nur ein Testdriver f�r die Musikerverwaltung.
 * 
 * @author Gabriele Schmidt
 * @version 0.1 
 * @since 02.05.2010
 * 
 */
public class Start  {
	

	private static final long serialVersionUID = 1L;

	public static void main(String[] args) {
//		new MusikerGUIFrame("Musikerverwaltung");
		new WerksGUIFrame("Orchesterwerkverwaltung");
	}
}
