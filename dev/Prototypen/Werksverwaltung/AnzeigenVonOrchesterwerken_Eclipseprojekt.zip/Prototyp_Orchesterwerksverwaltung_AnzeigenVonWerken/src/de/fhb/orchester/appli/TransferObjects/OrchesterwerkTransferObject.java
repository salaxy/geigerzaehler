package de.fhb.orchester.appli.TransferObjects;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import de.fhb.orchester.dbhibernate.persistence.Besetzung;


/**
 * F�r das Transferobjekt wurden �ffentliche Attribute gew�hlt.
 * Der Kontruktor k�nnte wegfallen, hilft aber bei der schnellen Objekterzeugung
 * 
 * Transferobjekte sollten immer serialisierbar sein!
 * 
 * @author Gabriele Schmidt
 * @version 0.1 
 * @since 08.04.2011
 * 
 */

public class OrchesterwerkTransferObject implements Serializable{
	/**
	 * 
	 */
	/**
	 * 
	 */
	private static final long serialVersionUID = 8717044998189634615L;
	public int werkId;
	public String typ;
	public String name;
	public String komponist;
	public short dauer;
	public boolean notenDa;
	public Set<Besetzung> besetzungs = new HashSet<Besetzung>(0);
	
	public OrchesterwerkTransferObject(int werkId, String typ, String name, String komponist,
		short dauer, boolean notenDa, Set<Besetzung> besetzungs) {
		this.werkId = werkId;
		this.typ = typ;
		this.name = name;
		this.komponist = komponist;
		this.dauer = dauer;
		this.notenDa = notenDa;
		this.besetzungs = besetzungs;
	}
	
	
	
}