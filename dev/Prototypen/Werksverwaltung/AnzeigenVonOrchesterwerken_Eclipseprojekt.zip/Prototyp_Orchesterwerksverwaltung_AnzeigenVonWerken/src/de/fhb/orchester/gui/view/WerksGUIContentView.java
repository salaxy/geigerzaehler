package de.fhb.orchester.gui.view;

import java.awt.Component;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Rectangle;

import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;

import de.fhb.orchester.gui.controller.OrchesterGUIController;

/**
 * Zeigt die Liste von Musikern an
 * Es ist eine Auswahl nach Instrumententyp m�glich.
 * 
 * @author Gabriele Schmidt
 * @version 0.1
 * @since 09.04.2011
 * 
 */
public class WerksGUIContentView extends JPanel {

	private static final long serialVersionUID = 1L;
	private JLabel labelListeMusiker = null;
	private JLabel labelMusiker = null;
	private JComboBox comboInstrumenttyp = null;
	private JList listMusikerErgebnisse = null;
	private JScrollPane scrollPaneErgebnisse = null;
	private OrchesterGUIController controller;

	private GridBagLayout gbl;

	/**
	 * Default-Konstruktor
	 */
	public WerksGUIContentView() {
		super();

		initialize();
		loadInstrumenttypen();
	}

	/**
	 * Diese Methode initialisiert ein Objekt der Klasse.
	 * Aufruf �ber den Default-Konstruktor
	 * 
	 * @return void
	 */
	private void initialize() {

		this.controller = new OrchesterGUIController();

		gbl = new GridBagLayout();

		this.setLayout(gbl);
		
//		labelListeMusiker = new JLabel();
//		labelListeMusiker.setText("Liste der Musiker");


//		labelMusiker = new JLabel();
//		labelMusiker.setText("Instrumenttyp:");
		
//		addComponent(labelListeMusiker,  0, 0, 1, 1, 0, 0);

//		addComponent(labelMusiker,  0, 1, 1, 1, 0, 0);

		addComponent(getComboBoxInstrumenttyp(), 2, 1, 1, 1, 0, 0);

		addComponent(getScrollPaneErgebnisse(),  0, 2, 4, 4, 1.0, 1.0);
		
		this.setSize(500, 500);
	}

//	/**
//	 * Diese Methode initialisiert comboInstrumenttyp
//	 * Bei der Auswahl eines anderen Elements der Combobox wird die listMusikerErgebnisse
//	 * neu gef�llt (s. loadText(String)
//	 * 
//	 * @return javax.swing.JComboBox 
//	 */
	private JComboBox getComboBoxInstrumenttyp() {
		if (comboInstrumenttyp == null) {
			comboInstrumenttyp = new JComboBox();
			comboInstrumenttyp.setBounds(new Rectangle(90, 16, 301, 30));
			comboInstrumenttyp
					.addActionListener(new java.awt.event.ActionListener() {
						public void actionPerformed(java.awt.event.ActionEvent e) {
							loadText((String) comboInstrumenttyp
									.getSelectedItem());
						}
					});
		}
		return comboInstrumenttyp;
	}
	
	/**
	 * Diese Methode initialisiert listMusikerErgebnisse
	 * 
	 * @return javax.swing.JList
	 */
	private JList getListErgebnisse() {
		if (listMusikerErgebnisse == null) {
			listMusikerErgebnisse = new JList();
		}
		listMusikerErgebnisse.setSize(300, 300);
		return listMusikerErgebnisse;
	}


	/**
	 * Diese Methode initialisiert scrollPaneErgebnisse. Das sind die Scrollbalken f�r listMusikerErgebnisse.
	 * 
	 * @return javax.swing.JTextArea
	 */
	private JScrollPane getScrollPaneErgebnisse() {
		if (scrollPaneErgebnisse == null) {
			scrollPaneErgebnisse = new JScrollPane(getListErgebnisse());
			scrollPaneErgebnisse
					.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
			scrollPaneErgebnisse
					.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);

		}
		return scrollPaneErgebnisse;
	}

	/**
	 * F�llt die Combobox mit Instrumenttypen einmal am Anfang
	 * 
	 */
	private void loadInstrumenttypen() {
//		String[] ausgabe = controller.loadInstrumenttypen();
		comboInstrumenttyp.removeAllItems();

		comboInstrumenttyp.addItem("alle");
//		for (String s : ausgabe) {
//			comboInstrumenttyp.addItem(s);
//		}
	}
	
	/**
	 * F�llt die Liste am Anfang und immer wenn in der Combobox wieder ein anderer Typ 
	 * ausgew�hlt wurde (s. ActionListener() in getComboBoxInstrumenttyp().
	 * 
	 */
	private void loadText(String instrumenttyp) {
		String[] ausgabe = controller.loadWerke(instrumenttyp);
		getListErgebnisse().setListData(ausgabe);
	}
	
	
	/**
	 * Hilfsmethode, um Contrains bei GridBagLayout zusetzen.
	 * 
	 */
	private void addComponent(Component c,  int x, int y, int width, int height,
			double weightx, double weighty) {
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.anchor = GridBagConstraints.WEST;
		gbc.fill = GridBagConstraints.BOTH;
		gbc.gridx = x;
		gbc.gridy = y;
		gbc.gridwidth = width;
		gbc.gridheight = height;
		gbc.weightx = weightx;
		gbc.weighty = weighty;
		gbc.insets = new Insets(2, 2, 2, 2);
		gbl.setConstraints(c, gbc);
		this.add(c);
	}
}
