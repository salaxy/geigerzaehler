package de.fhb.orchester.peristenzAccess;

import java.util.List;

import de.fhb.orchester.appli.TransferObjects.OrchesterwerkTransferObject;

/** Ist ein Interface f�r die Musikerverwaltung
 *  Entspricht dem Entwurfsmuster Fassade
 * 
 * @author Gabriele Schmidt
 * @version 0.1 
 * @since 09.04.2011
 * 
 */

public interface OrchesterwerkDAOInterface {
	public List<OrchesterwerkTransferObject> getAll();
//	public List<Orchesterwerk> getByInstrumenttyp(String name) ;
	
	
}
