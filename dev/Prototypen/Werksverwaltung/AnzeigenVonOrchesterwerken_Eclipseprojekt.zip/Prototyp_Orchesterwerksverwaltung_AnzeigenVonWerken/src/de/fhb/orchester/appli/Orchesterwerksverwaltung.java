package de.fhb.orchester.appli;

import java.util.ArrayList;
import java.util.List;
import de.fhb.orchester.appli.TransferObjects.OrchesterwerkTransferObject;
import de.fhb.orchester.peristenzAccess.DAOFactory;
import de.fhb.orchester.peristenzAccess.OrchesterwerkDAOInterface;

/**
 * Musikerverwaltung ist der eigentliche Controller in der Anwendungsschicht.
 * Hier wird mehr  Funktionalit�t entstehen als in dem Fassadencontroller, der einen Teil davon verbergen soll.
 * 
 * @author Gabriele Schmidt
 * @version 0.1 
 * @since 14.04.2011
 * 
 */
public class Orchesterwerksverwaltung {
	
	private OrchesterwerkDAOInterface werke;
//	private InstrumenttypDAOInterface instrumenttyp;
	private  List<OrchesterwerkTransferObject> listMto;
//	private List<InstrumenttypTransferObjekt> listIto;
	
	
	public Orchesterwerksverwaltung(){
		werke = DAOFactory.buildOrchesterwerkDAO();
//		instrumenttyp = DAOFactory.buildInstrumenttypDAO();
	}
	
	
	
	public List<OrchesterwerkTransferObject> getAll() {
		// TODO Auto-generated method stub
		listMto = werke.getAll();
		return listMto;
	}
	
	
//	public List<String> getInstrumenttyp() {
//		
//		
//		List<String> s = new ArrayList<String>();
//		listIto = instrumenttyp.getInstrumenttyp();
//		
//		for(InstrumenttypTransferObjekt ito : listIto)
//			s.add(ito.name);
//	
//		return s;
//	}

	
//	public List<MusikerTransferObject> getByInstrumenttyp(String name) {
//		// TODO Auto-generated method stub
//		String kuerzel = null;
//		
//		if(listIto == null)
//			listIto = instrumenttyp.getInstrumenttyp();
//		
//		for (InstrumenttypTransferObjekt ito : listIto)
//			if(ito.name.equals(name))
//				kuerzel = ito.kuerzel;
//		
//		return werke.getByInstrumenttyp(kuerzel);
//	}

}
