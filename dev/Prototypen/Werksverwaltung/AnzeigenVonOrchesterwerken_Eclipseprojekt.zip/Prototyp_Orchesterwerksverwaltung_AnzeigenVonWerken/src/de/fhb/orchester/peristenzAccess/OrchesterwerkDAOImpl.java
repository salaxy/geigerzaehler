package de.fhb.orchester.peristenzAccess;

import java.util.ArrayList;
import java.util.List;
import de.fhb.orchester.appli.TransferObjects.OrchesterwerkTransferObject;
import de.fhb.orchester.dbhibernate.persistence.Orchesterwerk;

/**
 * 
 * Implementiert das Interface RennstallDAOInterface, das nach au�en sichtbar
 * ist. Intern werden Eigenschaften von Hibernate gekapselt.
 * 
 * 
 * @author Gabriele Schmidt
 * @version 0.1
 * @since 02.05.2010
 * 
 */
public class OrchesterwerkDAOImpl extends HibernateDAO<Orchesterwerk> implements
OrchesterwerkDAOInterface {
	/**
	 * Default-Konstruktor
	 */
	public OrchesterwerkDAOImpl() {
		super();
	}

//	/**
//	 * Rennstaelle nach Name
//	 * 
//	 * @param name
//	 *            Name des Rennstalls
//	 * @return RennstallVOs
//	 */
//	@Override
//	public List<MusikerTransferObject> getByInstrumenttyp(String name) {
//		List<MusikerTransferObject> musikerTransfer = new ArrayList<MusikerTransferObject>();
//		List instr = query("from Instrumententyp where Kuerzel = '" + name
//				+ "'");
//
//		Iterator violinenIter = instr.iterator();
//		while (violinenIter.hasNext()) {
//
//			Instrumententyp instrumententypen = (Instrumententyp) violinenIter
//					.next();
//			Iterator<AngestellterMusiker> musiker = instrumententypen
//					.getSpielbarVon().iterator();
//			while (musiker.hasNext()) {
//
//				MusikerTransferObject mto = createObject(musiker.next());
//				musikerTransfer.add(mto);
//			}
//		}
//		return musikerTransfer;
//	}

	/**
	 * Alle Rennstaelle
	 * 
	 * @return RennstallVOs
	 */
	public List<OrchesterwerkTransferObject> getAll() {

		List<OrchesterwerkTransferObject> transfer = new ArrayList<OrchesterwerkTransferObject>();
		List<Orchesterwerk> werke;
		werke = query("from Orchesterwerk as r");

		for (Orchesterwerk m : werke) {
			OrchesterwerkTransferObject mto = createTransferObject(m);

			transfer.add(mto);
		}
		return transfer;
	}

	/**
	 * Erzeugt das RennstalltransferObjekt und RennfahrerTransferobjekt
	 * 
	 * @param r
	 *            Typ de.fhb.formel1.dbhibernate.persistence.Rennstall
	 * @return RennstallTransferObjekt
	 */
	private OrchesterwerkTransferObject createTransferObject(Orchesterwerk am) {
		OrchesterwerkTransferObject objekt = 
		new OrchesterwerkTransferObject(am.getWerkId(), am.getTyp(), am.getName(), am.getKomponist(),am.getDauer(), am.getNotenDa(), am.getBesetzungen());

		return objekt;
	}

}
