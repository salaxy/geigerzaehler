package de.fhb.orchester.gui.view;



import java.awt.*;
import javax.swing.JFrame;


import de.fhb.orchester.gui.controller.WindowClosingAdapter;

/**
 * Ist  ein Fenster f�r die Musikerverwaltung.
 * 
 * @author Gabriele Schmidt
 * @version 0.1 
 * @since 02.05.2010
 * 
 */
public class WerksGUIFrame extends JFrame {

	private static final long serialVersionUID = 1L;
	private WerksGUIContentView myPanel;
	private Container c;
	
	public WerksGUIFrame(String Title) {
		super(Title);
		init();
	}
	
	public void init() {
		//Bei Swing wichtig, da Standardkomponente bereits ein Panel ist.
		c = getContentPane();  

		
		// Eigenen Inhalt als Panel hinzuf�gen
		myPanel = new WerksGUIContentView();
		c.add(myPanel);
		
	
	    pack();
		setVisible(true); /* Fenster soll sichtbar sein */
		
	
		//Listener f�r Fenster zum Schlie�en
		addWindowListener(new WindowClosingAdapter(true));
	}
	
}
