package de.fhb.orchester.gui.controller;

import java.util.ArrayList;
import java.util.List;

import de.fhb.orchester.appli.TransferObjects.OrchesterwerkTransferObject;
import de.fhb.orchester.appli.controller.ControllerFactory;
import de.fhb.orchester.appli.controller.OrchesterwerksverwaltungControllerInterface;



/**
 * Soll den Ablauf von Menus im GUI steuern. (Gibt es jetzt noch nicht.)
 * Greift auf die n�chste darunterliegende Schicht zu. (Verbindung von View und Modell)
 * 
 * @author Gabriele Schmidt
 * @version 0.1 
 * @since 09.04.2011
 * 
 */
public class OrchesterGUIController {
	
	private OrchesterwerksverwaltungControllerInterface controller ;

	
	public OrchesterGUIController() {
		controller = ControllerFactory.buildWerksController();
	}
	
	public String [] loadWerke(String instrumenttyp) {
		String s;
		String [] sArray;
		ArrayList<String> strings = new ArrayList<String>();
		List<OrchesterwerkTransferObject> werke;

//		if(instrumenttyp.equals("alle")) {
			 werke = controller.getAll();
//		}
//		else {
//			musiker = musikerController.getByInstrumenttyp(instrumenttyp);
//		}
//		
		for(OrchesterwerkTransferObject m : werke ){	
				s =  m.werkId +" - "+m.name +  " - " + m.komponist +" - " + m.typ;
				strings.add(s);
		}
			

		 sArray = new  String[strings.size()];
		 return  strings.toArray(sArray);
	}
	
//	public String [] loadInstrumenttypen(){
//		
//		String [] sArray;
//
//		List<String> instrumenttypen = musikerController.getInstrumenttyp();
//		
//		 sArray = new  String[instrumenttypen.size()];
//		 return  instrumenttypen.toArray(sArray);
//	}
	
} 
