package de.fhb.orchester.example;

import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import de.fhb.orchester.dbhibernate.persistence.AngestellterMusiker;
import de.fhb.orchester.dbhibernate.persistence.Instrumententyp;
import de.fhb.orchester.dbhibernate.util.HibernateUtil;

/**
 * Kleines TestBeispiel zur Benutzung der Orchester-Persistenzschicht.
 * Anleitung:
 * - Anlegen der Datenbank
 *   Skripte create.sql und insert.sql in database/sybase im eigenen 
 *   Sybase-DB-Bereich anlegen.
 * - Konfiguration der Persistenzschicht
 *   Die Konfigurationsdatei muss hibernate.cfg.xml heissen. Zur Benutzung von
 *   Sybase ist die Datei sybase-hibernate.cfg.xml entsprechend umzubenennen.
 *   Es sind die ersten drei Properties url, username und password anzupassen.
 * - Ausfuehren der Beispiel-Applikation.
 *   
 * Zum Wechsel von Sybase zu einer lokalen MySQL-Datenbank ist folgendes zu tun
 * - Anlegen der Datenbank (vgl. Skripte unter database/mysql)
 * - Konfigurieren der hibernate.cfg.xml
 * - Wechsel der JDBC-Bibliothek:
 *   Anstelle von jconn2.jar ist das jar unter lib/jdbc-mysql einzubinden.
 *   
 * @author Susanne Busse
 */
public class OrchesterExampleApplication {

	
	/**
	 * druckt die angestellten Musiker aus (mit Name, Vorname und ggf. 
	 * Geburtsdatum), die ein bestimmtes Instrument spielen k�nnen. 
	 * @param instr Instrument, dessen Spieler ausgegeben werden sollen
	 */
	private static void printViolinenSpieler(Instrumententyp instr) {

		if (instr == null)
			return;
		
		System.out.println("\n" + instr.getName() + " wird gespielt von:");

		Iterator<AngestellterMusiker> musiker = instr.getSpielbarVon().iterator();
		while (musiker.hasNext()) {
			
			AngestellterMusiker curMusiker = musiker.next();
			System.out.print("  " + curMusiker.getVorname());
			System.out.print(" " + curMusiker.getName());
			Date gebdatum = curMusiker.getGebDatum();
			if (gebdatum != null)
				System.out.println(", geb. am " + curMusiker.getGebDatum());
			else
				System.out.println();
			
		}

	}
	
	
	/**
	 * Sucht Violinen heraus (1. und 2. Violine) und gibt die angestellten Musiker aus,
	 * die dieses Instrument jeweils spielen k�nnen.
	 */
	public static void main(String[] args) {
		
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;

		try {

			System.out.println("Herzlich Willkommen!");
			
			tx = session.beginTransaction();

			// liste der Saisons, an denen Ferrari teilgenommen hat, ermitteln
			List violinen = session.createQuery("from Instrumententyp "
					              + "where Kuerzel = 'Vl1' or Kuerzel = 'Vl2'").list();

			Iterator violinenIter = violinen.iterator();
			while (violinenIter.hasNext()) {

				Instrumententyp violine = (Instrumententyp) violinenIter.next();			
				printViolinenSpieler(violine);

			}

			tx.commit();

		} catch (Exception e) {
			
			System.out.println(e.getMessage());
			if (tx != null) 
				tx.rollback();
						
		} finally {
			
			// Shutting down the application
			session.close();
			HibernateUtil.shutdown();
			
		}

	}

}
