/**
 * Data-Access-Object fuer Rennstaelle
 */

package de.fhb.orchester.appli.controller;

import java.util.List;

import de.fhb.orchester.appli.Orchesterwerksverwaltung;
import de.fhb.orchester.appli.TransferObjects.OrchesterwerkTransferObject;


/**
 * 
 * Implementiert das Interface MusikerverwaltungControllerInterface, das nach au�en (z. B. GUI) sichtbar ist.
 * Intern wird Musikerverwaltung aufgerufen.
 * Kann die Aufgabe eines Use Case Controllers (s. Vorlesung sp�ter) �bernehmen
 * 
 * @author Gabriele Schmidt
 * @version 0.1 
 * @since 09.04.2011
 
 */
public class OrchesterwerksverwaltungControllerImpl implements OrchesterwerksverwaltungControllerInterface{
	
	private Orchesterwerksverwaltung musikerverwaltung;
	/**
	 * Default-Konstruktor
	 */
	public OrchesterwerksverwaltungControllerImpl() {
		super();
		musikerverwaltung = new Orchesterwerksverwaltung();
	}
	@Override
	public List<OrchesterwerkTransferObject> getAll() {
		// TODO Auto-generated method stub

		return musikerverwaltung.getAll();
	}
	
//	@Override
//	public List<String> getInstrumenttyp() {
//		return musikerverwaltung.getInstrumenttyp();
//	}
//
//	@Override
//	public List<MusikerTransferObject> getByInstrumenttyp(String name) {
//		// TODO Auto-generated method stub
//		return musikerverwaltung.getByInstrumenttyp(name);
//	}
	
}
