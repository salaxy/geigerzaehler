package de.fhb.orchester.appli.controller;

import java.util.List;

import de.fhb.orchester.appli.TransferObjects.OrchesterwerkTransferObject;

/** Ist ein Interface f�r die Musikerverwaltung, das nach au�en (z. B. GUI) sichtbar ist.
 *  Entspricht dem Entwurfsmuster Fassade
 * 
 * @author Gabriele Schmidt
 * @version 0.1 
 * @since 09.04.2011
 * 
 */

public interface OrchesterwerksverwaltungControllerInterface {
	public List<OrchesterwerkTransferObject> getAll();
	
}
