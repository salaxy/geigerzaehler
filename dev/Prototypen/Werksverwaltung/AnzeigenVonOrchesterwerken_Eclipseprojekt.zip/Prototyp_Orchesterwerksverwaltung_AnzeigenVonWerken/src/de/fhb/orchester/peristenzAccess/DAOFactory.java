package de.fhb.orchester.peristenzAccess;


/**
 * 
 * Die DAOFactory erzeugt DAO, so dass nur die Interfaces der DAOs
 * genutzt werden m�ssen.
 * 
 * GGf. muss die Factory noch so erweitert werden, dass verschiedene 
 * DAOs erzeugt werden k�nnen.
 * 
 * @author Gabriele Schmidt
 * @version 0.1 
 * @since 02.05.2010
 * 
 */

public class DAOFactory {

//	public static MusikerDAOInterface buildMusikerDAO() {
//        return new MusikerDAOImpl();
//    }
//	
//	public static InstrumenttypDAOInterface buildInstrumenttypDAO() {
//        return new InstrumenttypDAOImpl();
//    }
//	
	public static OrchesterwerkDAOInterface buildOrchesterwerkDAO() {
        return new OrchesterwerkDAOImpl();
    }

}
