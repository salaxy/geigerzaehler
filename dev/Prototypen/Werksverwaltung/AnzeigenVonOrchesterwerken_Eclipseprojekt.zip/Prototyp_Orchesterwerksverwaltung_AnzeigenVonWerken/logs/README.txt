In diesem Verzeichnis werden Log-Dateien abgelegt.
Konfiguration �ber die Datei src/log4j.properties:
Als rootLogger muss der FileAppender hinzugef�gt werden.